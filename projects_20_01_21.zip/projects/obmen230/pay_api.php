<?php

namespace Pay;
class Payme
{
    public function Curl($post) {

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://payme.uz/api",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $post,
            CURLOPT_HTTPHEADER => array(
                "cache-control: no-cache",
                "content-type: application/json"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            return "cURL Error #:" . $err;
        } else {
            return json_decode($response);
        }
    }
// PAYME TO UZCARD
    public function perevod($summa, $oluvchi, $yuboruvchi, $karta_sana)
    {

       return $this->Curl("{\n\"method\": \"fast_p2p.create\",\n\"params\": {\n\"amount\": $summa,\n\"number\": \"$oluvchi\",\n\"pay_card\": {\n\"number\": \"$yuboruvchi\",\n\"expire\": \"$karta_sana\"\n}\n}\n}");
    }

    public function sms($cheq_id)
    {
         return $this->Curl("{\n\"method\": \"fast_p2p.get_pay_code\", \n\"params\": {\n\"id\": \"$cheq_id\"\n}\n}");
    }
public function sendcode($id,$code) {
        return$this->Curl("{\n\"method\": \"fast_p2p.pay\",\n\"params\": {\n\"id\": \"$id\",\n\"code\": \"$code\"\n}\n}");
}





}




