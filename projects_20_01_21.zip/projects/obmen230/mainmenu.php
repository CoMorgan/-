<?php
date_default_timezone_set('Asia/Tashkent');
require_once 'class.php';

use app\TelegramBot;
$bot = new TelegramBot;
require_once 'sqlite.php';
$db = new Db('base.sqlite');
$data = $bot->getData("php://input");


	
if ($data['message']) {
    $chat_id = $data['message']['chat']['id'];
    $userid = $data['message']['from']['id'];
    $username = $data['message']['from']['username'];
    $ism = $data['message']['from']['first_name'] . ' ' . $data['message']['from']['last_name'];
 $ban = $db->queryRow('SELECT ban FROM users WHERE chat_id = "'.$chat_id.'" ')['ban'];
if ($ban == 0) {
   $text = $data['message']['text'];
}
    $message_id = $data['message']['message_id'];
}

if ($data['callback_query']) {
//CALLBACK
    $callback = $data['callback_query'];
    $callid = $callback['id'];
    $i_m_id = $callback['inline_message_id'];
    $cdata = $callback['data'];
    $chat_id = $callback['message']['chat']['id'];
    $message_id = $callback['message']['message_id'];
    $call_text = $callback['message']['text'];
}
$admin = 266873587;//tasdiqlovchi admin
$admin_card = $bot->getData('lang/admin_card.txt');
$adm = ['266873587', '768814928'];//
$minimal = $bot->getData('lang/min.txt');
$maximal = $bot->getData('lang/max.txt');
$K = $bot->getData('lang/prosent.txt');
///////   base locatsiya /////
$loc = $db->queryRow('SELECT * FROM users WHERE chat_id = "'.$chat_id.'" ')['geo'];

$menu = $bot->keyboard([[['text' => $bot->lng('balansTo', $cdata)]],[['text'=>$bot->lng('balansoff', $cdata)],['text'=>$bot->lng('wallet', $cdata)]],[['text'=>$bot->lng('pay_history', $cdata)],['text'=>$bot->lng('guide', $cdata)]], [['text'=>$bot->lng('sellRubl', $cdata)],['text'=>$bot->lng('call', $cdata)]]]);

if($text == "/start") {
$bot->rg('sendmessage', $chat_id, "Выберите язык интерфейса💬\n\nInterfeys tilini tanlang", $bot->inlinekeyboard([[['text'=>"🇷🇺 Русский", 'callback_data'=>"ru"],['text'=>"🇺🇿 O'zbek tili", 'callback_data'=>"uz"]]]));
$count = $db->queryValue('SELECT COUNT (*) FROM users WHERE chat_id = "'.$chat_id.'" ');
if ($count == 0) {
$db->exec('INSERT INTO "users" ("chat_id", "geo")
    VALUES ("'.$chat_id.'", "fio")');
} else {
	

$db->update('users', array('geo' => "#"), 'chat_id=:id', array(':id' => $chat_id)); 

}
}
	

if ($cdata == "uz") {

$db->update('users', array('lang' => 'uz'), 'chat_id=:id', array(':id' => $chat_id)); 
$bot->dMessage($chat_id, $message_id);
$bot->rg('sendmessage', $chat_id, $bot->lng('about', $cdata), $menu);
}
if ($cdata == "ru") {
$db->update('users', array('lang' => 'ru'), 'chat_id=:id', array(':id' => $chat_id)); 

$bot->dMessage($chat_id, $message_id);
$bot->rg('sendmessage', $chat_id, $bot->lng('about', $cdata), $menu);

} 

$fiotel=	$db->queryRow('SELECT * FROM users WHERE chat_id = "'.$chat_id.'" ');
 $pLang = file_get_contents('lang/'.$fiotel['lang'].'.yml');


if ($text)	{
		if ($fiotel['fio'] == false) {
	$db->update('users', array('geo' => 'fio'), 'chat_id=:id', array(':id' => $chat_id)); 
			} else {
	if ($fiotel['tel'] == false)	{
	$db->update('users', array('geo' => 'tel'), 'chat_id=:id', array(':id' => $chat_id)); 

		}//tel
			}
		}
		
			if ($loc == "fio") {
				if (mb_stripos($pLang, $text) !== false) { 
			$bot->rg(sendmessage, $chat_id, $bot->lng('fio'))	;
	} else {
							
	if (mb_strlen($text) > 12) {
		$abs = array("'", "*", "#", ",", "@");
		$bsa = array("", "", "", "", "");
		$text = str_replace($abs, $bsa, $text);
		$bot->rg(sendmessage, $chat_id, $bot->lng('telNumber'), $bot->keyboard([[['text'=>$bot->lng('sendNumber'), 'request_contact'=>true]]]));
	$db->exec("UPDATE users SET fio='".$text."', geo='tel'  WHERE chat_id='".$chat_id."' ");

		}
		}
	}
	
	
			if ($loc == "tel") {
				if (mb_stripos($pLang, $text) !== false) { 
			$bot->rg(sendmessage, $chat_id, $bot->lng('telNumber'), $bot->keyboard([[['text'=>$bot->lng('sendNumber'), 'request_contact'=>true]]]));
						} else {
							
	$tel = $data[message][contact][phone_number];
if ($tel == true) {
		$db->update('users', array('tel'=> $tel, 'geo'=>'#'), 'chat_id=:id', array(':id' => $chat_id)); 
$bot->rg(sendmessage, $chat_id, $bot->lng('checking'), $menu);
$danny =	$db->queryRow('SELECT * FROM users WHERE chat_id = "'.$chat_id.'" ');
$newReg = "*Yangi foydalanuvchi:*
F.I.SH: ".$danny['fio']."
Tel: ".$danny['tel']."
Telegrami: [".$chat_id."](tg://user?id=".$chat_id.")";
$bot->rg(sendmessage, $admin, $newReg, $bot->inlinekeyboard([[['text'=>"Aktivlash", 'callback_data'=>"activ".$chat_id]]]));
}	
		}
		}
	
		
		
if (!empty($fiotel['fio']) && !empty($fiotel['tel'])) {// F.I.O mavjudmi

	if ($bot->getData('tanaffus.txt') == true) {	
		if (mb_stripos($text, "/start") !==false || $cdata) { } else {
		$bot->rg(sendmessage, $chat_id, $bot->lng('timeout')); }
		} else {
					if ($text == $bot->lng('menu')) {
						$bot->rg(sendmessage, $chat_id, $bot->lng('about'), $menu);
						$db->update('users', array('geo' => 'menu'), 'chat_id=:id', array(':id' => $chat_id)); 

						} 
if ($text == $bot->lng('wallet')) {
	$info =	$db->queryRow('SELECT * FROM users WHERE chat_id = "'.$chat_id.'" ');
$uzcard = (true == $info['card']) ? $info['card'] : $bot->lng('noWallet'); 
$xbet = (true == $info['xbet']) ? $info['xbet'] : $bot->lng('noWallet'); 
$linebet = (true == $info['linebet']) ? $info['linebet'] : $bot->lng('noWallet'); 

$toWallet = $bot->keyboard([[['text'=>"➕ UZCARD / HUMO"], ['text' =>"➕ 1XBET"], ['text' =>"➕ LineBET"]],[['text'=>$bot->lng('menu')]]]);
$bot->rg(sendmessage, $chat_id, $bot->lng('onWallet'), $toWallet);

$bot->dMessage($chat_id, $m->result->message_id);
$wallet = "🔖* UZCARD / HUMO:*
`$uzcard`
🔖 *1XBET:*
`$xbet`
🔖 *LineBET:*
`$linebet`";
	$bot->rg(sendmessage, $chat_id, $wallet, $bot->inlinekeyboard([[['text'=>$bot->lng('clear'), 'callback_data'=>"clear"]]]));
	}
	if ($text == $bot->lng('sellRubl')) {
		
		$bot->rg(sendmessage, $chat_id, $bot->lng('toSellrub'), $bot->inlinekeyboard([[['text'=>$bot->lng('wAdmin'), 'url'=>"https://t.me/the_pay_support"]]]));
		}
		
		if ($text == $bot->lng('balansoff')) {
						$bot->rg(sendmessage, $chat_id, $bot->lng('upBalans'), $bot->inlinekeyboard([[['text'=>"1XBET UZS", 'callback_data'=>"up1xbet"]],[['text'=>"LineBET UZS", 'callback_data'=>"uplinebet"]]]));
			}
			if ($text == $bot->lng('guide')) {
			//	$qullanma_v = "BAACAgIAAxkBAAEHZDNf4iCICbFnFj6gnzgQATOs4qaVVwACtgwAAl1QCUuIWo3FuGrwCh4E";
		//	$bot->sendVideo(['chat_id'=>$chat_id, 'video'=>$qullanma_v, 'caption'=>$bot->lng('qullanma_text'), 'parse_mode'=>"markdown"])	;
$bot->rg(sendmessage, $chat_id, "Скоро");
								}
			if ($text == $bot->lng('call')) {
				$toAdmin = $bot->lng('call_info_admin');
				$bot->rg(sendmessage, $chat_id, $toAdmin, $bot->inlinekeyboard([[['text'=>$bot->lng('wAdmin'), 'url'=>"https://t.me/the_pay_support"]]]));
				}
				
	if ($text == "➕ UZCARD / HUMO") {
		$send = $bot->lng('writeUzcard');
		$bot->rg(sendmessage, $chat_id, $send);
		$db->update('users', array('geo' => 'uzcard'), 'chat_id=:id', array(':id' => $chat_id)); 
						
						}
		
			if ($text == "➕ 1XBET") {
		$send = $bot->lng('writexBet');
		$bot->rg(sendmessage, $chat_id, $send);
	$db->update('users', array('geo' => '1xbet'), 'chat_id=:id', array(':id' => $chat_id)); 

			}
			
				if ($text == "➕ LineBET") {
		$send = $bot->lng('writelineBet');
		$bot->rg(sendmessage, $chat_id, $send);
	$db->update('users', array('geo' => 'linebet'), 'chat_id=:id', array(':id' => $chat_id)); 

			}
			
			if ($loc == "uzcard") {
					$strUzcard = preg_replace("/[^0-9]/", '', $text);
if ($strUzcard == true) {
$db->update('users', array('card' => $strUzcard, 'geo'=>'#'), 'chat_id=:id', array(':id' => $chat_id)); 
$bot->rg(sendmessage, $chat_id, $bot->lng('successCard'));
	}
				}
				
					if ($loc == "expire") {
					$strExpire = preg_replace("/[^0-9]/", '', $text);
if ($strExpire == true) {
$db->update('users', array('expire' => $strExpire, 'geo'=>'wallet'), 'chat_id=:id', array(':id' => $chat_id)); 
$bot->rg(sendmessage, $chat_id, $bot->lng('successCard'));
	}
				}
				
					if ($loc == "1xbet") {
					$strBet = preg_replace("/[^0-9]/", '', $text);
if ($strBet== true) {
$db->update('users', array('xbet' => $strBet, 'geo'=>"#"), 'chat_id=:id', array(':id' => $chat_id)); 
$tosend = str_replace('{bet}', "1XBET", $bot->lng('successBet'));
$bot->rg(sendmessage, $chat_id, $tosend);
	}
				}
					if ($loc == "linebet") {
					$strBet = preg_replace("/[^0-9]/", '', $text);
if ($strBet== true) {
$db->update('users', array('linebet' => $strBet, 'geo'=>"#"), 'chat_id=:id', array(':id' => $chat_id)); 
$tosend = str_replace('{bet}', "LineBET", $bot->lng('successBet'));
$bot->rg(sendmessage, $chat_id, $tosend);
	}
				}				
if ($cdata == "clear") {
	$bot->dMessage($chat_id, $message_id);
	$bot->rg(sendmessage, $chat_id, $bot->lng('clearing'));       
			$db->update('users', array('geo' => "wallet", 'card'=>'', 'xbet'=>'', 'linebet'=>''), 'chat_id=:id', array(':id' => $chat_id)); 
	}
	
if ($cdata == "up1xbet")	{
	$v_ID = "BAACAgQAAxkBAAEHcsVf6CC0C3N_Lx6ettgQraNvAAFHbWcAAl8CAALrtYVRGZKdmXU04NkeBA";
$bot->dMessage($chat_id, $message_id);
$xbetup = $bot->inlinekeyboard([[['text'=>$bot->lng('idsend'), 'callback_data'=>"idsend"]],[['text'=>$bot->lng('menu'), 'callback_data'=>"menu"]]]);
		$bot->sendVideo(['chat_id'=>$chat_id, 'video'=>$v_ID, 'caption'=>"🎲 1XBET:\nСкоро", 'reply_markup'=>$xbetup]);
		}
		if ($cdata == "uplinebet")	{
	$v_ID = "BAACAgQAAxkBAAEHcsVf6CC0C3N_Lx6ettgQraNvAAFHbWcAAl8CAALrtYVRGZKdmXU04NkeBA";
$bot->dMessage($chat_id, $message_id);
$xbetup = $bot->inlinekeyboard([[['text'=>$bot->lng('idsend'), 'callback_data'=>"idsend"]],[['text'=>$bot->lng('menu'), 'callback_data'=>"menu"]]]);
		$bot->sendVideo(['chat_id'=>$chat_id, 'video'=>$v_ID, 'caption'=>"🎲 LineBET:\nСкоро", 'reply_markup'=>$xbetup]);
		}
		
if ($cdata == "idsend") {
preg_match_all('|🎲 (.*):|Uis', $data['callback_query']['message']['caption'], $xbuy);
$xbet = ("1XBET" == $xbuy[1][0]) ? "idsend" : "idsend"; 
$bot->dMessage($chat_id, $message_id);
$bot->rg(sendmessage, $chat_id, "🎲 *".$xbuy[1][0]."*\n\n".$bot->lng('sendID'));
	$db->update('users', array('geo' => "$xbet"), 'chat_id=:id', array(':id' => $chat_id)); 

$fp = fopen("upBalans/$chat_id.txt", "w");
fwrite($fp, "🎲 ".$xbuy[1][0]);
fclose($fp);
	}
if ($loc == "idsend") {
	if (is_numeric($text) == true) {
	$v = "\nID: $text";
file_put_contents("upBalans/$chat_id.txt", $v, FILE_APPEND);
$bot->rg(sendmessage, $chat_id, $bot->lng('secretCode'));
	$db->update('users', array('geo' => "secret"), 'chat_id=:id', array(':id' => $chat_id)); 
}
	}
		if ($text == true) {
	if ($loc == "secret") {
	$v = "\nKOD: $text";
file_put_contents("upBalans/$chat_id.txt", $v, FILE_APPEND);
$row =	$db->queryRow('SELECT * FROM users WHERE chat_id = "'.$chat_id.'" ');
		$ad_vivod = file_get_contents("upBalans/$chat_id.txt")."
Aloqa: [".$row['tel']."](tg://user?id=$chat_id)";
$bot->rg(sendmessage, $chat_id, $bot->lng('succUp'), $menu);
$bot->rg(sendmessage, $admin, $ad_vivod);
	$db->update('users', array('geo' => "#"), 'chat_id=:id', array(':id' => $chat_id)); 
unlink("upBalans/$chat_id.txt");
}
	}
	
if (mb_stripos($cdata, "activ")!==false) {
	$ID = explode('activ', $cdata)[1];
	$bot->go('editMessageReplyMarkup', ['chat_id'=>$chat_id, 'message_id'=>$message_id, 'inline_message_id'=>$i_m_id, 'reply_markup'=>$bot->inlinekeyboard([[['text'=>"✅", 'callback_data'=>"#"]]])]);
$bot->rg(sendmessage, $ID, $bot->lng('regest'));
				$db->update('users', array('checking' => "1"), 'chat_id=:id', array(':id' => $ID)); 

	}		
	
	if ($text == $bot->lng('balansTo')) {
	$schet =	$db->queryRow('SELECT * FROM users WHERE chat_id = "'.$chat_id.'" ');
	if ($schet['checking'] == 1) {
			$vProgress = $db->queryRow('SELECT * FROM history WHERE chat_id = "'.$chat_id.'" AND status = "admin" ');
if ($vProgress['status'] == "admin") {//vProgeess
	$bot->rg(sendmessage, $chat_id, $bot->lng('vProgress'));
	} else {//vProgress
		$sendTo = $bot->lng('warningCard');
										$bot->rg(sendmessage, $chat_id, $sendTo, $bot->inlinekeyboard([[['text'=>$bot->lng('goObmen'), 'callback_data' =>"toBK"]]]));
			
	}//VProgress
	
	} else {//tekshiruvdan o'tish
	$bot->rg(sendmessage, $chat_id, $bot->lng('checking'));
	}	
		}
	
		if ($cdata == "toBK") {
			$bot->dMessage($chat_id, $message_id);
			$viberite = $bot->lng('viberite');
			$inlineKontora = $bot->inlinekeyboard([[['text'=>"🎲 1XBET UZS", 'callback_data'=>"toXbet"]], [['text'=>"🎲 LineBET UZS", 'callback_data'=>"toLbet"]]]);
	$bot->rg(sendmessage, $chat_id, $viberite, $inlineKontora);
			}
			
		if ($cdata == "toXbet" || $cdata == "toLbet")	 {
			$bot->dMessage($chat_id, $message_id);
	$schet =	$db->queryRow('SELECT * FROM users WHERE chat_id = "'.$chat_id.'" ');
$betting = ("toXbet" == $cdata) ? $schet['xbet'] : $schet['linebet']; 

								if ($schet['card'] == true && $betting == true) {				

				$tobalans = "*".$bot->lng('write_sum')."*
".$bot->lng('minimal').": ".$minimal." ".$bot->lng('summa')."
".$bot->lng('maximal').": ".$maximal." ".$bot->lng('summa')."
".$bot->lng('komis').": $K%";
$schet =	$db->queryRow('SELECT * FROM users WHERE chat_id = "'.$chat_id.'" ');

	$vProgress = $db->queryRow('SELECT * FROM history WHERE chat_id = "'.$chat_id.'" AND status = "admin" ');
if ($vProgress['status'] == "admin") {//vProgeess
	$bot->rg(sendmessage, $chat_id, $bot->lng('vProgress'));
	} else {//vProgress
						$bot->rg(sendmessage, $chat_id, $tobalans, $bot->keyboard([[['text'=>$bot->lng('menu')]]]));
	$db->update('users', array('geo' => 'summa'), 'chat_id=:id', array(':id' => $chat_id)); 

	$betname = ("toXbet" == $cdata) ? "1XBET": "LineBET"; 
					$check_hist = $db->queryValue('SELECT COUNT (*) FROM history WHERE chat_id = "'.$chat_id.'" AND status = "loading" ');
if ($check_hist == 0) {
$db->exec('INSERT INTO "history" ("chat_id", "betname", "status")
    VALUES ("'.$chat_id.'", "'.$betname.'", "loading")'); } else {
$db->exec("UPDATE history SET betname='".$betname."'  WHERE chat_id='".$chat_id."' AND status = 'loading' ");
}		
}//VProgress
							} else {
		$bot->dMessage($chat_id, $message_id-1);
				$bot->dMessage($chat_id, $message_id);
			$bot->rg(sendmessage, $chat_id, $bot->lng('walletNo'), $menu);

							}// hamyonlar				
			}
			
		
if ($text == $bot->lng('pay_history')) {
	$sendH = $bot->lng('history_style');
	$vHistory = $db->queryRows('SELECT * FROM history WHERE chat_id = "'.$chat_id.'" AND (status = "success" OR status = "otmen")ORDER BY time DESC LIMIT 20 ');
foreach($vHistory as $vH) {

$arrayH = ["{id}", "{bk}", "{toSom}", "{onSom}", "{succ}", "{time}"];
$nSom= $vH['summa'] / 100 * $K;
		$onSom = $vH['summa'] - $nSom;
		$succ =  ("success" == $vH['status']) ? '✅' : '❌'; 
		$time = date('H:i - d.m.Y', $vH['time']);
$toarrayH = [$vH['id'], $vH['betname'], $vH['summa'], $onSom, $succ, $time];
$sendHis = str_replace($arrayH, $toarrayH, $sendH);
$bot->rg(sendmessage, $chat_id, $sendHis);
}
$lastHist = $bot->lng('lastHist');
$lastHist = str_replace("{countH}", count($vHistory), $lastHist);
$bot->rg(sendmessage, $chat_id, $lastHist);
	}
}//Tanafus		
	
	}// Fio
	
		if ($text == $bot->lng('menu') || $text == "/start" || $text == $bot->lng('balansoff') || $text == $bot->lng('wallet') || $text == $bot->lng('pay_history') || $text == $bot->lng('guide') || $text == $bot->lng('sellRubl') || $text == $bot->lng('call')) {} else { //Istisno so"zlar ishlaganda halaqit bermasin

		
if ($loc == "summa")	{
	$str = preg_replace("/[^0-9]/", '', $text);
	
		if ($str > $minimal - 1 && $str < $maximal +1) {
		$totext = $bot->lng('payTocard');
		$totext = str_replace('{summa}', $str, $totext);
		$zProcent = $str / 100 * $K;
		$mProcent = $str - $zProcent;
		$bk = $db->queryRow('SELECT * FROM history WHERE chat_id = "'.$chat_id.'" AND status = "loading" ');
		$totext = str_replace(['{tosum}', '{bk}'], [$mProcent, $bk['betname']], $totext);
		$bot->rg(sendmessage, $chat_id, $totext, $bot->inlinekeyboard([[['text'=>$bot->lng('paying'), 'callback_data'=>"paytocard"]]]));
	$count = $db->queryValue('SELECT COUNT (*) FROM history WHERE chat_id = "'.$chat_id.'" AND status = "loading" ');
if ($count == 0) {
$db->exec('INSERT INTO "history" ("chat_id", "summa", "status")
    VALUES ("'.$chat_id.'", "'.$str.'", "loading")'); } else {
$db->exec("UPDATE history SET summa='".$str."'  WHERE chat_id='".$chat_id."' AND status = 'loading' ");

}
$db->update('users', array('geo' => 'peymi'), 'chat_id=:id', array(':id' => $chat_id)); 

				} else {
				$tobalans = "*".$bot->lng('write_sum')."*
".$bot->lng('minimal').": ".$minimal." ".$bot->lng('summa')."
".$bot->lng('maximal').": ".$maximal." ".$bot->lng('summa')."
".$bot->lng('komis').": $K%";
			$bot->dMessage($chat_id, $message_id-1);
				$bot->dMessage($chat_id, $message_id);
			$bot->rg(sendmessage, $chat_id, $tobalans, $bot->keyboard([[['text'=>$bot->lng('menu')]]]));
	
		}
		
	}
	if ($cdata == "paytocard") {
		$bot->dMessage($chat_id, $message_id);
		$matn = $bot->lng('paytoadmin');
		$b = $db->queryRow('SELECT * FROM history WHERE chat_id = "'.$chat_id.'" AND status = "loading" ');
$matn = str_replace(["{hisob}", "{sena}"], [$bot->getData('lang/admin_card.txt'), $b['summa']], $matn);
	$bot->rg(sendmessage, $chat_id, $bot->getData('lang/admin_card.txt'))	;
$inline_ptc = $bot->inlinekeyboard([[['text'=>$bot->lng('tuladim'), 'callback_data'=>"tuladim"]]]);
		$bot->rg(sendmessage, $chat_id, $matn, $inline_ptc);
		}
		if ($cdata == "tuladim") {
						$q = $db->queryRow('SELECT * FROM history WHERE chat_id = "'.$chat_id.'" AND status = "loading" ');
$yuzer = $db->queryRow('SELECT * FROM users WHERE chat_id = "'.$chat_id.'" ');

			$bet = ("1XBET" == $q['betname']) ? "❗ 1XBET: `".$yuzer['xbet']."`" : "❗ LineBET: `".$yuzer['linebet']."`"; 
$zProcent = $q['summa'] / 100 * $K;
		$adSum = $q['summa'] - $zProcent;
							$admintotext = "*Yangi to'lov:* ({$q['id']})
F.I.SH: [#{$yuzer['fio']}](tg://user?id=$chat_id)
Tel: `{$yuzer['tel']}`
Card: `{$yuzer['card']}`
O'tkazdi: `{$q['summa']}` so'm
Yuborasiz: `{$adSum}` so'm
$bet";
$ad_inline = $bot->inlinekeyboard([[['text'=>"To'landi", 'callback_data'=>"succPey"]],[['text'=>"Bekor qilish", 'callback_data'=>"notPey"]], [['text'=>"🚫 BAN", 'callback_data'=>"ban"]]]);
				$toUser = $bot->lng('successPayment');		
					  $bot->rg(sendmessage, $chat_id, $toUser, $menu); //USERGA XABAR
				  	$bot->rg(sendmessage, $admin, $admintotext, $ad_inline);
	
		$db->update('users', array('geo' => '#'), 'chat_id=:id', array(':id' => $chat_id)); //Locatsiyani yangilash	
    $db->exec("UPDATE history SET status='admin', time='".time()."'  WHERE chat_id='".$chat_id."' AND status = 'loading' ");
		
			$bot->dMessage($chat_id, $message_id-1);
	$bot->dMessage($chat_id, $message_id);
			}
			
//payme 
	/**
if ($cdata == "paytocard") {
	$mrg = ['callback_query_id'=>$callid, 'text' => $bot->lng('jdikod')];
$bot->go('answerCallbackQuery', $mrg);
	$info =	$db->queryRow('SELECT * FROM users WHERE chat_id = "'.$chat_id.'" ');
$card = $info['card']; // Klent kartasi
$expire = $info['expire']; // Karta Muddati
$zayavka = $db->queryRow('SELECT * FROM history WHERE chat_id = "'.$chat_id.'" AND status = "loading" ');
$summa = $zayavka['summa'] * 100; // O'tkazadigan summasi

$paytocard = $Pay->perevod($summa, $admin_card, $card, $expire);
		$cheque_id = $paytocard->result->cheque->_id;
		$smstoTel = $Pay->sms($cheque_id);
		$kodsms = str_replace('{tel}', $smstoTel->result->phone, $bot->lng('smskod'));
		$kodsms = str_replace('*', '×', $kodsms);
		$bot->rg(sendmessage, $chat_id, $kodsms);
		//Json tekshieuv $bot->sendMessage(['chat_id'=>$chat_id, 'text'=>json_encode($smstoTel)]);
$db->update('users', array('geo' => 'smskod'), 'chat_id=:id', array(':id' => $chat_id)); 
$db->exec("UPDATE history SET chek_id='".$cheque_id."'  WHERE chat_id='".$chat_id."' AND status = 'loading' ");

$bot->dMessage($chat_id, $message_id);
				}
				
				if ($loc == "smskod") {
			$chek_id = $db->queryRow('SELECT * FROM history WHERE chat_id = "'.$chat_id.'" AND status = "loading" ');
$yuzer = $db->queryRow('SELECT * FROM users WHERE chat_id = "'.$chat_id.'" ');

		$kod = preg_replace("/[^0-9]/", '', $text);
				$jsonprc =	$Pay->sendcode($chek_id['chek_id'], $kod);
				$send = $bot->lng($jsonprc->error->code); // error kodi orqali otvet
					if ($jsonprc->result->cheque == true) {
					$bet = ("1XBET" == $chek_id['betname']) ? "❗ 1XBET: `".$yuzer['xbet']."`" : "❗ LineBET: `".$yuzer['linebet']."`"; 
$zProcent = $chek_id['summa'] / 100 * $K;
		$adSum = $chek_id['summa'] - $zProcent;
							$admintotext = "*Yangi to'lov:* ({$chek_id['id']})
F.I.SH: [#{$yuzer['fio']}](tg://user?id=$chat_id)
Tel: `{$yuzer['tel']}`
Card: `{$yuzer['card']}`
O'tkazdi: `{$chek_id['summa']}` so'm
Yuborasiz: `{$adSum}` so'm
$bet";
$ad_inline = $bot->inlinekeyboard([[['text'=>"To'landi", 'callback_data'=>"succPey"]],[['text'=>"Bekor qilish", 'callback_data'=>"notPey"]], [['text'=>"🚫 BAN", 'callback_data'=>"ban"]]]);
				$toUser = $bot->lng('successPayment');
			//	$toUser = str_replace('{karta}', $yuzer['card'], $toUser);
				//$toUser = str_replace('{summa}', $chek_id['summa'], $toUser);
				  $bot->rg(sendmessage, $chat_id, $toUser, $menu); //USERGA XABAR
				  	$bot->rg(sendmessage, $admin, $admintotext, $ad_inline);
	
		$db->update('users', array('geo' => 'start'), 'chat_id=:id', array(':id' => $chat_id)); //Locatsiyani yangilasj			
    $db->exec("UPDATE history SET status='admin', time='".time()."'  WHERE chat_id='".$chat_id."' AND status = 'loading' ");


						} else {// Error api 
							$bot->sendMessage(['chat_id'=>$chat_id, 'text'=>$send]);
			}
					}
		
	**/				
					} //istisno buyruqlarga halaqit bermasin	
					
if ($cdata == "succPey") {
	preg_match_all('|: \((.*)\)|Uis', $call_text, $pChek);
 $P = $pChek[1][0];
	$user = $db->queryRow('SELECT * FROM history WHERE id = "'.$P.'" AND status = "admin" ');
$sendU = "🇺🇿 Hisobingiz to'ldirildi botimizdan foydalanganingiz uchun rahmat!
🇷🇺 Ваш счет пополнен. Спасибо за использование нашего бота.";
$bot->rg(sendmessage, $user['chat_id'], $sendU, $menu);
$bot->go('editMessageReplyMarkup', ['chat_id' => $chat_id, 'message_id' => $message_id, 'inline_message_id' => $callid, 'reply_markup' => json_encode(['inline_keyboard' => [[['text' => "✅ To'langan", 'callback_data' => "x"]]]])]);
 $db->update('history', array('status' => 'success'), 'id=:id', array(':id' => $P)); 
 
	}
	
	if ($cdata == "notPey") {
	preg_match_all('|: \((.*)\)|Uis', $call_text, $pChek);
 $P = $pChek[1][0];
	$user = $db->queryRow('SELECT * FROM history WHERE id = "'.$P.'" AND status = "admin" ');
$sendU = "❌ To'lovingiz bekor qilindi
❌ Ваш заявка отменен";
$bot->rg(sendmessage, $user['chat_id'], $sendU, $menu);
$bot->go('editMessageReplyMarkup', ['chat_id' => $chat_id, 'message_id' => $message_id, 'inline_message_id' => $callid, 'reply_markup' => json_encode(['inline_keyboard' => [[['text' => "Bekor qilingan", 'callback_data' => "x"]]]])]);
  $db->update('history', array('status' => 'otmen'), 'id=:id', array(':id' => $P)); 
 
	}
	
	if ($cdata == "ban") {
	preg_match_all('|: \((.*)\)|Uis', $call_text, $pChek);
 $P = $pChek[1][0];
	$user = $db->queryRow('SELECT * FROM history WHERE id = "'.$P.'" AND status = "admin" ');

$bot->go('editMessageReplyMarkup', ['chat_id' => $chat_id, 'message_id' => $message_id, 'inline_message_id' => $callid, 'reply_markup' => json_encode(['inline_keyboard' => [[['text' => "BAN", 'callback_data' => "x"]]]])]);
  $db->update('users', array('ban' => '1'), 'chat_id=:id', array(':id' => $user['chat_id'])); 
 $db->update('history', array('status' => 'otmen'), 'id=:id', array(':id' => $user['id'])); 
 
	}

	if (in_array($chat_id, $adm)) {
		
		if (mb_stripos($text, "/off") !==false) {
			file_put_contents('tanaffus.txt', '1');
			$bot->rg(sendmessage, $chat_id, "Tanaffus o'rnatildi");
			}
			if (mb_stripos($text, "/on") !==false) {
			file_put_contents('tanaffus.txt', '0');
			$bot->rg(sendmessage, $chat_id, "Tanaffus yakunlandi");
			}
if(mb_stripos($text,"##") !== false) {
$mid = $data['message']['reply_to_message']['message_id'];

file_put_contents('sendAll/rass.txt', json_encode($data));

$bot->rg('sendmessage', $chat_id, "*Tayyor:* /Yubor Yuborishga tayyor");
// строка, которую будем записывать
$texti = file_get_contents('sendAll/txt.txt');
 
$fp = fopen("sendAll/cron.php", "w");
 
fwrite($fp, $texti);
 
fclose($fp);
}
if ($text == "/Yubor") {
file_put_contents('sendAll/next.txt', '0');
file_put_contents('sendAll/stop.txt', '0');
$bot->go('sendMessage', ['chat_id'=>$admin, 'text'=>"Habar yetkazilmoqda..."]);
file_get_contents('http://obmen200.cf/obmen200/sendAll/cron.php');
}
if (mb_stripos($text, "/card") !==false) {
	$ex = explode('=', $text)[1];
			file_put_contents('lang/admin_card.txt', $ex);
			$bot->rg(sendmessage, $chat_id, "Admin kartasi yangilandi");
			}
			if (mb_stripos($text, "/min") !==false) {
	$ex = explode('=', $text)[1];
			file_put_contents('lang/min.txt', $ex);
			$bot->rg(sendmessage, $chat_id, "Minimal so'mma yangilandi");
			}
			
			if (mb_stripos($text, "/max") !==false) {
	$ex = explode('=', $text)[1];
			file_put_contents('lang/max.txt', $ex);
			$bot->rg(sendmessage, $chat_id, "Maksimal so'mma yangilandi");
			}
		if (mb_stripos($text, "/foiz") !==false) {
	$ex = explode('=', $text)[1];
			file_put_contents('lang/prosent.txt', $ex);
			$bot->rg(sendmessage, $chat_id, "Protsent yangilandi");
			}
						}
						
						
						
						
						


?>