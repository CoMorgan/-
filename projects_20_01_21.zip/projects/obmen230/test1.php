<?php
/*
require_once 'sendMoney.php';

$sendMoney = $API->sendMoney('100000', '8600042391353736', '8600042359933974', '1023');
$holdids = $sendMoney->data->operationHoldId;
$phone = $sendMoney->data->phone;

echo $holdids . $phone;

echo '<br/>'.json_encode($sendMoney);
*/
use GuzzleHttp\Client;

require_once 'vendor/autoload.php';

$client = new Client();
$cJson = '{"operationHoldId": "8e648645-5c16-4e81-ac0f-46d0e4487901", "smsCode": "61835"}';
$response = $client->post('https://mobile.kapitalbank.uz/api/transaction/p2p', [
    'headers' => [
        'cache-control'=> 'no-cache',
        'content-type'=> 'application/json;charset=UTF-8',
        'device-id'=> 'kapital-web-site',
        'lang'=> 'uz',
        'postman-token'=> 'f99eda37-29f9-d54f-2253-031f4aeadd52',
        'token'=> 'Vs1A1asiw6UtI7gX2AP1kFEpFiTRJyix'
    ],
    'body' => $cJson
]);

$bodyc = $response->getBody();
$decodec = json_decode($bodyc->getContents());
echo json_encode($decodec);
