<?php

use GuzzleHttp\Client;
require_once 'vendor/autoload.php';

$client = new Client();

//namespace Pay;
class Payme {

	public function Curl($json) {
		global $client;
$response = $client->post('https://payme.uz/api', [
    'headers' => ['Content-Type' => 'application/json'],
    'body' => $json
]);

$body = $response->getBody();
	$decode = json_decode($body->getContents());
	return $decode;
}
public function perevod($summa, $oluvchi, $yuboruvchi, $karta_sana)
    {

       return $this->Curl("{\n\"method\": \"fast_p2p.create\",\n\"params\": {\n\"amount\": $summa,\n\"number\": \"$oluvchi\",\n\"pay_card\": {\n\"number\": \"$yuboruvchi\",\n\"expire\": \"$karta_sana\"\n}\n}\n}");
    }

    public function sms($cheq_id)
    {
         return $this->Curl("{\n\"method\": \"fast_p2p.get_pay_code\", \n\"params\": {\n\"id\": \"$cheq_id\"\n}\n}");
    }
public function sendcode($id,$code) {
        return$this->Curl("{\n\"method\": \"fast_p2p.pay\",\n\"params\": {\n\"id\": \"$id\",\n\"code\": \"$code\"\n}\n}");
}


}




$Pay = new Payme();


?>



