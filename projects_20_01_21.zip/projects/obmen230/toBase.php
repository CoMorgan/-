<?php

require_once 'sqlite.php';
$db = new Db('base.sqlite');

$get = file_get_contents('users.txt');
$ex = explode("\n", $get);
$i = 0;
foreach($ex as $exx){
echo "<br>$i) ".$exx."</br>";

$count = $db->queryValue('SELECT COUNT (*) FROM users WHERE chat_id = "'.$exx.'" ');
if ($count == 0) {
$db->exec('INSERT INTO "users" ("chat_id", "geo")
    VALUES ("'.$exx.'", "#")');
echo '<span style="color: green;">OK</span>';
}
$i++;
}

?>