<?php

$geo = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$cid.'" ');
$typ = $db->queryRow('SELECT * FROM obmen WHERE cid = "'.$cid.'" AND sts = "loading" ');
if ($typ['btype'] == "UZBSO'M") {
$tur = str_replace('QIWI RUBL', 'qiwi', $typ['otype']);
$tur = str_replace('YANDEX RUBL', 'yandex', $tur);
$tur = str_replace('WMZ', 'wmz', $tur);
$tur = str_replace('1XBET UZS', 'xbetuzs', $tur);


$rub = str_replace('YANDEX RUBL', $yan, $typ['otype']);
$rub = str_replace('WMZ', $wmz, $rub);
$rub = str_replace('QIWI RUBL', $qiv, $rub);

if($tur == "xbetuzs") {
$max = get('byudjet/xbetuzs.rg')+0.1; } 
if($tur == "wmz") {
$c = $wmzmin-0.01;
$max = get('byudjet/wmz.rg') * $wmz + 0.00001;
} else {
$max = get('byudjet/'.$tur.'.rg') * $rub + 0.1;
$c = $sum_min-1; }

} else if ($typ['btype'] == "WMZ") {
$ty = $typ['otype'];
if ($ty == "UZBSO'M") {
$tt = str_replace("UZBSO'M", "wmzuzs", $ty);

$max = get('byudjet/'.$tt.'.rg') / $wmzo;
$c = $dollir_min-0.01;
} 
} else if($typ['btype'] == "YANDEX RUBL") {
$uf = $typ['otype'];
if ($uf == "UZBSO'M") {
$tt = str_replace("UZBSO'M", "yandexuzs", $uf);

$max = get('byudjet/'.$tt.'.rg') / $ya+1;
$c = $rub_min-0.1;
}
} else if($typ['btype'] == "QIWI RUBL") {
$tq = $typ['otype'];
if($tq == "UZBSO'M") {
$tt = str_replace("UZBSO'M", "qiwiuzs", $tq);
$max = get('byudjet/'.$tt.'.rg') / $qi;
$c = $rub_min-0.01;
} 
} 
//tugash

if ($geo['geo'] == "otdachi") {
if ($tex < $max && $tex > $c) {//###########################



if ($typ['btype'] == "UZBSO'M") {
$ssum = str_replace('QIWI RUBL', $qiv, $typ['otype']);
$ssum = str_replace('YANDEX RUBL', $yan, $ssum);
$ssum = str_replace('WMZ', $wmz, $ssum);
 if ($ssum == "1XBET UZS") {
	
$xbetuzs = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$cid.'" ');
	
$f = $tex * get('byudjet/foiz.txt') / 100;

$xuz = $tex - $f;
$olamiz = $xuz; } else { $olamiz = $tex / $ssum; }

} else if($typ['btype'] == "WMZ") {
$trr = $typ['otype'];
if($trr == "UZBSO'M") {
$olamiz = $tex * $wmzo;
} 
} else if($typ['btype'] == "YANDEX RUBL") {
$ti = $typ['otype'];
if($ti == "UZBSO'M") {
$olamiz = $tex * $ya;
}
} else if($typ['btype'] == "QIWI RUBL") {
$tq = $typ['otype'];
if ($tq == "UZBSO'M") {
$olamiz = $tex * $qi;
}
}


$u = $olamiz;
$n = explode(".", $u)[1];
$a = substr($n, 2);
if ($a == true) {
	$ole = str_replace($a, '', $u);
	} else {
$oldik = number_format($olamiz, 2, '.', '');
$ole = $oldik;
}
$db->exec("UPDATE obmen SET berish='".$tex."', olish='".$ole."' WHERE cid='".$cid."' AND sts = 'loading' ");

$q = $typ;
$us = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$cid.'" ');
if ($q['btype'] == "YANDEX RUBL") { $ber = "*Yandex: ".$us['yandex']."*"; } else if ($q['btype'] == "UZBSO'M") { $ber = "*CARD: ".$us['uzcard']."*"; } else if ($q['btype'] == "QIWI RUBL") { $ber = "*QIWI: ".$us['qiwi']."*"; } else if ($q['btype'] == "WMZ") {$ber = "*WMZ: ".$us['wmz']."*"; } 

if ($q['otype'] == "QIWI RUBL") { $ol = "*QIWI: ".$us['qiwi']."*"; } else if ($q['otype'] == "YANDEX RUBL") { $ol = "*Yandex: ".$us['yandex']."*"; } else if ($q['otype'] == "UZBSO'M") { $ol = "*CARD: ".$us['uzcard']."*"; } else if($q['otype'] == "WMZ") { $ol = "*WMZ: ".$us['wmz']."*"; } else if($q['otype'] == "1XBET UZS") { $ol = "*1XBET UZS: ".$us['xbetuzs']."*"; } 

$tug = json_encode(['inline_keyboard'=>[[['text'=>til(tulash), 'callback_data'=>"tulash"]],[['text'=>til(otmen), 'callback_data'=>"otmen"]]]]);


$qo = til(zayom)."\nID: `".$q['id']."`\n".til(berish)." ".$tex." ".$q['btype']."\n".til(olish)." ".$ole." ".$q['otype']."`*`\n".$ber."\n".$ol."\n".til(komissiya);

rg('sendmessage', $cid, $qo, $tug); 
} else if (preg_match('/1|2|3|4|5|6|7|8|9|0|\./i', $tex)){ rg('sendmessage', $cid, til(noturi));
}
}






//########################################################

 if($typ['btype'] == "UZBSO'M" && $typ['otype'] == "QIWI RUBL") {
$maxx = str_replace("QIWI RUBL", get('byudjet/qiwi.rg'), $typ['otype']);

$maxx = $maxx+0.01;
$s = $rub_min-0.01;  
} else if($typ['btype'] == "UZBSO'M" && $typ['otype'] == "WMZ") {
$maxx = str_replace("WMZ", get('byudjet/wmz.rg'), $typ['otype']);

$maxx = $maxx+0.001;
$s = $dollir_min-0.001;
} else if ($typ['otype'] == "UZBSO'M" || $typ['otype'] == "1XBET UZS") {
$UZV = str_replace(["QIWI RUBL", "YANDEX RUBL", "WMZ"], ["qiwiuzs", "yandexuzs", "wmzuzs"], $typ['btype']);
$tt = str_replace("UZBSO'M", $UZV, $typ['otype']);
$tt = str_replace('1XBET UZS', 'xbetuzs', $tt);
$maxx = get('byudjet/'.$tt.'.rg')+0.01;
 $s = $sum_min-0.01; 
} else if ($typ['otype'] == "WMZ") { $maxx = get('byudjet/wmz.rg')+0.01; $s = $dollir_min-0.01; 
} else if($typ['otype'] == "QIWI RUBL") { $maxx = get('byudjet/qiwi.rg')+0.01;
$s = $rub_min-0.01; 
} else if ($typ['otype'] == "YANDEX RUBL") {
$maxx = get('byudjet/yandex.rg')+0.01;
$s = $rub_min-0.01;
} 

if ($geo['geo'] == "poluchi") {

if ($tex < $maxx && $tex > $s) { 
if ($typ['btype'] == "UZBSO'M") {
if ($typ['otype'] == "QIWI RUBL" || $typ['otype'] == "YANDEX RUBL" || $typ['otype'] == "WMZ") {
$kurs = str_replace('QIWI RUBL', $qiv, $typ['otype']);
$kurs = str_replace('YANDEX RUBL', $yan, $kurs);
$kurs = str_replace('WMZ', $wmz, $kurs);

$olamiz = $tex * $kurs; 
}
if ($typ['otype'] == "1XBET UZS") {
$xbetuzs = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$cid.'" ');
	
$f = $tex * get('byudjet/foiz.txt') / 100;

$olamiz = $tex + $f;
}
} else if($typ['btype'] == "WMZ") {
if ($typ['otype'] == "UZBSO'M" || $typ['otype'] == "QIWI RUBL") {
$mo = str_replace("UZBSO'M", $wmzo, $typ['otype']);
$mo = str_replace('QIWI RUBL', $wmz_r, $mo);

$olamiz = $tex / $mo;
}

} else if ($typ['btype'] == "YANDEX RUBL") {
if ($typ['otype'] == "UZBSO'M") {
 $olamiz = $tex / $ya;
}
} else if($typ['btype'] == "QIWI RUBL") {
if ($typ['otype'] == "UZBSO'M") {
$olamiz = $tex / $qi; 
} 
}

 


$x = explode('.', $olamiz);
$y = str_replace($x[1], '', $olamiz);
$berdik = $y.substr($x[1], 0,2);
 $ole = $tex; 

$db->exec("UPDATE obmen SET berish='".$berdik."', olish='".$ole."' WHERE cid='".$cid."' AND sts = 'loading' ");

$q = $typ;
$us = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$cid.'" ');
if ($q['btype'] == "YANDEX RUBL") { $ber = "*YANDEX: ".$us['yandex']."*"; } else if ($q['btype'] == "UZBSO'M") { $ber = "*UZBSO'M: ".$us['uzcard']."*";  } else if ($q['btype'] == "QIWI RUBL") {$ber = "*QIWI: ".$us['qiwi']."*";  } else if ($q['btype'] == "WMZ") { $ber = "*WMZ: ".$us['wmz']."*"; }

if ($q['otype'] == "QIWI RUBL") { $ol = "*QIWI: ".$us['qiwi']."*"; } else if ($q['otype'] == "YANDEX RUBL") { $ol = "*YANDEX: ".$us['yandex']."*"; } else if ($q['otype'] == "UZBSO'M") { $ol = "*UZBSO'M: ".$us['uzcard']."*"; } else if ($q['otype'] == "WMZ") { $ol = "*WMZ: ".$us['wmz']."*"; } else if($q['otype'] == "1XBET UZS") { $ol = "*1XBET UZS: ".$us['xbetuzs']."*"; }


$tug = json_encode(['inline_keyboard'=>[[['text'=>til(tulash), 'callback_data'=>"tulash"]],[['text'=>til(otmen), 'callback_data'=>"otmen"]]]]);

$qo = til(zayom)."\nID: `".$q['id']."`\n".til(berish)." ".$berdik." ".$q['btype']."\n".til(olish)." ".$ole." ".$q['otype']."`*`\n".$ber."\n".$ol."\n".til(komissiya);
rg('sendmessage', $cid, $qo, $tug);
} else if (preg_match('/1|2|3|4|5|6|7|8|9|0|\./i', $tex)){ rg('sendmessage', $cid, til(noturi)); }
}//OLISH QIYMATI






?>