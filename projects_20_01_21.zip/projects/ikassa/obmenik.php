<?php
date_default_timezone_set('Asia/Tashkent');
require_once('info.php');
include 'sqlite/lib/sqlite.php';
$db = new Db('malumot.sqlite');

require_once('kurslar.php');



$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$cid = $message->chat->id;
$tex = $message->text;
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

if ($message) { $kid = $cid; } else { $kid = $update->callback_query->message->chat->id; }
$em = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$kid.'" ');
define('ID',$em['user_id']);
define('FIO',$em['fio']);


function rg($met, $sid, $matn, $markup = false, $md = false) {

return bot($met, [
        'chat_id' => $sid,
'message_id'=>$md,
        'text' => $matn,
        'parse_mode'=>"markdown",
'reply_markup'=>$markup,
'disable_web_page_preview'=>true
    ]); 
}

 
function ACL($callbackQueryId, $text = null, $showAlert = false)
{
     return bot('answerCallbackQuery', [
        'callback_query_id' => $callbackQueryId,
        'text' => $text,
        'show_alert'=>$showAlert,
    ]);
}
function get($fayl){
$get = file_get_contents("$fayl");
return $get;
}

$menu_ru = json_encode(['one_time_keyboard'=>true, 'resize_keyboard'=>true,
'keyboard'=>[[['text'=>"🔄Обмен"]],[['text'=>"🔰Кошельки"],['text'=>"📊Курс и 💰Резервы"]],[['text'=>"📂История заявок"],['text'=>"🎫 КИВИ Идентификатсия"]],[['text'=>"👥Рефералы"],['text'=>"📞Тех.поддержка"]],]]);
$menu_uz = json_encode(['one_time_keyboard'=>true, 'resize_keyboard'=>true,
'keyboard'=>[[['text'=>"🔄Valyuta ayirboshlash"]],[['text'=>"🔰Hamyonlar"],['text'=>"📊Kurs va 💰Zahira"]],[['text'=>"📂Almashuvlar"],['text'=>"🎫 QIWI Identifikatsiya"]],[['text'=>"👥Referallar"],['text'=>"📞Aloqa"]],]]);

//#
$admin = ['426517395','266873587'];
$adm = "@obmenniy";//Glavniy

if ($update->callback_query) $id = $update->callback_query->message->chat->id; else $id = $message->chat->id;
$tili = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$id.'" ');
$tyl = $tili['lang'];

define('TIL',$tyl);
function til($tl) {
$ln = file_get_contents("lang_".TIL.".lng");
preg_match_all('|'.$tl.'="(.*)"|Uis', $ln, $ex);
return $ex[1][0];
}
$menu = json_encode(['one_time_keyboard'=>true, 'resize_keyboard'=>true,
'keyboard'=>[[['text'=>til(obmen)]],[['text'=>til(danniy)],['text'=>til(kurs)]],[['text'=>til(istoriya)],['text'=>til(identifikat)]],[['text'=>til(ref)],['text'=>til(aloqa)]],]]);
///CALLBACK QISM


  $call=$update->callback_query;
$dat=$call->data;
$mid = $call->message->message_id;
$chid = $call->message->chat->id;



if($tex == "/start") {
rg('sendmessage', $cid, "Выберите язык интерфейса💬\n\nInterfeys tilini tanlang", json_encode(['inline_keyboard'=>[[['text'=>"Русский", 'callback_data'=>"ru"],['text'=>"O'zbek tili", 'callback_data'=>"uz"]]]]));
$count = $db->queryValue('SELECT COUNT (*) FROM users WHERE user_id = "'.$cid.'" ');
if ($count == 0) {
$db->exec('INSERT INTO "users" ("user_id")
    VALUES ("'.$cid.'")');
}
}

if ($dat == "uz") {

$db->update('users', array('lang' => 'uz', 'geo' => 'start'), 'user_id=:id', array(':id' => $chid)); 
rg('deleteMessage', $chid, true, true, $mid);
rg('sendmessage', $chid, "*".$company."* - bu O'zbekiston hududidagi *ishonchli valyuta almashuv servisi.*", $menu_uz);
}
if ($dat == "ru") {
$db->update('users', array('lang' => 'ru', 'geo'=> 'start'), 'user_id=:id', array(':id' => $chid)); 

rg('deleteMessage', $chid, true, true, $mid);
rg('sendmessage', $chid, "*".$company."* - это *надежный сервис обмена валют на территории Узбекистана.*", $menu_ru);

}


$otdat  = json_encode(['inline_keyboard'=>[[['text'=>"⏫ UZBSO'M", 'callback_data'=>"uzcardb"],['text'=>"⏬  UZBSO'M", 'callback_data'=>"uzcardo"]],[['text'=>"⏫ WMZ", 'callback_data'=>"wmzb"],['text'=>"⏬ WMZ", 'callback_data'=>"wmzo"]],[['text'=>"⏫ YANDEX RUBL", 'callback_data'=>"yandexb"],['text'=>"⏬ YANDEX RUBL", 'callback_data'=>"yandexo"]],[['text'=>"⏫ QIWI RUBL", 'callback_data'=>"qiwib"],['text'=>"⏬ QIWI RUBL", 'callback_data'=>"qiwio"]],[['text'=>"▫️", 'callback_data'=>"x"],['text'=>"⏬ 1XBET UZS", 'callback_data'=>"xbetuzso"]],]]);
if (!empty($em['fio'])) {//FiSh

if ($em['ban'] == "0") {//BANLANDI

if ($tex == til(obmen)) {
if (get('off.morgan') == false) {//STOP
$obe = $db->queryValue('SELECT COUNT (*) FROM obmen WHERE cid = "'.$cid.'" AND sts = "tekshiruv" ');
if($obe == 0) {
$tili = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$cid.'" ');
rg('sendmessage', $cid, til(obmenit), $otdat);
$db->exec("UPDATE obmen SET otype='', btype='' WHERE cid='".$cid."' AND sts = 'loading' ");
$db->exec("UPDATE users SET geo='' WHERE user_id='".$cid."' ");
} else {

$kx = til(kuting);
rg('sendmessage', $cid, $kx, json_encode(['inline_keyboard'=>[[['text'=>til(holatimiz), 'callback_data'=>"holat"]]]]));}

} else {//STOP
rg('sendmessage', $cid, "*".get('off.morgan')."*");
}
}
}//BAN



if ($dat == "holat") {
$dan = $db->queryRow('SELECT * FROM obmen WHERE cid = "'.$chid.'" ORDER BY time DESC');
$sts = str_replace('tekshiruv', til(prover), $dan['sts']);
$sts = str_replace('success', til(tulandi), $sts);
$sts = str_replace('otmen', til(otmen), $sts);
$ho = "ID: ".$dan['id']."\n".til(berish)." ".$dan['berish']." ".$dan['btype']."\n".til(olish)." ".$dan['olish']." ".$dan['otype']."\n".til(sts)." ".$sts."\n".til(time)." ".date('d.m.y / H:i:s', $dan['time']);
bot('answerCallbackQuery',
 ['callback_query_id'=>$call->id, 'text' => $ho, 'show_alert'=>true]);
}


// OBMENNING FILE
include 'almashuv.php'; 

// 1XBET PUNKT


	$tugma_xbet = json_encode(['inline_keyboard'=>[[['text'=>til(typing), 'url'=>"https://t.me/c_morgan"]],]]);

if($tex == til(identifikat)) {
		
		rg('sendmessage', $cid, til(identifikatsiya), $tugma_xbet);
		}


if ($dat == "otmen") {
$db->exec("DELETE FROM obmen WHERE cid='".$chid."' AND sts = 'loading' ");
rg('deleteMessage', $chid, true, true, $mid);
rg('sendmessage', $chid, "*".til(bekor)."*", $menu);
}

//##########################BAZAGA HISOB KIRITISH###########################

$cash = json_encode(['one_time_keyboard'=>true, 'resize_keyboard'=>true,
'keyboard'=>[[['text'=>"➕UZCARD / HUMO"],['text'=>"➕YANDEX"]],[['text'=>"➕QIWI"],['text'=>"➕WMZ"]],[['text'=>"➕1XBET UZS"]],[['text'=>til(menu)]]]]);
$caw = json_encode(['inline_keyboard'=>[[['text'=>til(chistit), 'callback_data'=>"clear"]]]]);
$danniy = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$cid.'" ');
if (!empty($danniy['yandex'])) {
$yandex = $danniy['yandex']; } else { $yandex = til(pusto); }
if (!empty($danniy['qiwi'])) {
$qiwi = $danniy['qiwi']; } else { $qiwi = til(pusto); }
if (!empty($danniy['uzcard'])) {
$uzcard = $danniy['uzcard']; } else { $uzcard = til(pusto); }
if (!empty($danniy['wmz'])) {
$wmz = $danniy['wmz']; } else { $wmz = til(pusto); }
if (!empty($danniy['xbetuzs'])) {
$xbz = $danniy['xbetuzs']; } else { $xbz= til(pusto); }

$kash = "📌*QIWI:*
`".$qiwi."`
📌*YANDEX:*
`".$yandex."`
📌*UZCARD / HUMO:*
`".$uzcard."`
📌*1XBET UZS:*
`".$xbz."`
📌*WMZ:*
`".$wmz."`";
if ($tex == til(danniy)) {
rg('sendmessage', $cid, til(kashelok), $cash);
rg('sendmessage', $cid, $kash, $caw);
$db->exec("UPDATE users SET geo='dannie' WHERE user_id='".$cid."' ");
//$db->exec("UPDATE obmen SET otype='', btype='' WHERE cid='".$cid."' AND sts = 'loading' ");
}
if ($tex == "➕QIWI" || $tex == "➕YANDEX" || $tex == "➕UZCARD / HUMO" || $tex == "➕WMZ" || $tex == "➕1XBET UZS") {
$kashe = str_replace('➕QIWI', til(schet_q), $tex);
$kashe = str_replace('➕YANDEX', til(schet_y), $kashe);
$kashe = str_replace('➕UZCARD / HUMO', til(schet_c), $kashe);
$kashe = str_replace('➕WMZ', til(schet_wz), $kashe);
$kashe = str_replace('➕1XBET UZS', til(schet_xbz), $kashe);
$db->exec("UPDATE users SET geo='".$tex."' WHERE user_id='".$cid."' ");


rg('sendmessage', $cid, $kashe);
}
$d = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$cid.'" ');
if($d['geo'] == "➕QIWI") {
if(mb_stripos($tex,"+99") !== false || mb_stripos($tex,"+7") !== false){
$no = substr($tex, 0, 13);
$d['geo'] = str_replace('➕', '', $d['geo']);
$j = str_replace('{kash}', $d['geo'], til(uspeshno));
rg('sendmessage', $cid, $j);
$db->exec("UPDATE users SET qiwi='".$no."', geo='#' WHERE user_id='".$cid."' ");
}}

if($d['geo'] == "➕UZCARD / HUMO") {
if(mb_stripos($tex,"8600") !== false || stripos($tex,"6262") !== false){
$tex = str_replace(' ', '', $tex);
if (strlen($tex) > 15){
$no = substr($tex, 0, 16);
$d['geo'] = str_replace('➕', '', $d['geo']);
$j = str_replace('{kash}', $d['geo'], til(uspeshno));

rg('sendmessage', $cid, $j);
$db->exec("UPDATE users SET uzcard='".$no."', geo='#' WHERE user_id='".$cid."' ");
}}}


if($d['geo'] == "➕YANDEX") {

if (preg_match('/[0-9]/i', $tex)){
if (strlen($tex) > 12){
$no = is_int($tex);
$d['geo'] = str_replace('➕', '', $d['geo']);
$j = str_replace('{kash}', $d['geo'], til(uspeshno));

rg('sendmessage', $cid, $j);
$db->exec("UPDATE users SET yandex='".$tex."', geo='#' WHERE user_id='".$cid."' ");
}}}

if($d['geo'] == "➕WMZ") {
if (preg_match('/Z/i', $tex)){
if (preg_match('/[0-9]/i', $tex)){
if (strlen($tex) > 12){

$d['geo'] = str_replace('➕', '', $d['geo']);
$j = str_replace('{kash}', $d['geo'], til(uspeshno));

rg('sendmessage', $cid, $j);
$db->exec("UPDATE users SET wmz='".$tex."', geo='#' WHERE user_id='".$cid."' ");
}}}}


if($d['geo'] == "➕1XBET UZS") {
if (preg_match('/1|2|3|4|5|6|7|8|9|0/i', $tex)){
if (strlen($tex) < 11){

$d['geo'] = str_replace('➕', '', $d['geo']);
$j = str_replace('{kash}', $d['geo'], til(uspeshno));

rg('sendmessage', $cid, $j);
$db->exec("UPDATE users SET xbetuzs='".$tex."', geo='#' WHERE user_id='".$cid."' ");
}}}

if($tex == til(menu)) {
rg('sendmessage', $cid, til(menu), $menu);
}
if($dat == "clear") {
$db->exec("UPDATE users SET geo='#', qiwi='', yandex='', uzcard='', xbetuzs='', wmz='' WHERE user_id='".$chid."' ");

rg('deleteMessage', $chid, true, true, $mid);
rg('sendmessage', $chid, til(toza));

}


$wmzzz = $db->queryRow('SELECT * FROM valyut WHERE turi = "wmz" ');
$wmzz = $wmzzz['sotish'];
if($tex == til(kurs)) {
$rez = json_encode(['inline_keyboard'=>[[['text'=>til(rezerv), 'callback_data'=>"rezerv"]]]]);
$mm = til(prodaj)."\n1 QIWI RUBL = `".$qiv."` UZS\n1 YANDEX RUBL = `".$yan."` UZS\n1 WMZ = `".$wmzz."` UZS\n1 1XBET UZS = `".$foiz."%`\n\n".til(pokup)."\n1 QIWI RUBL = `".$qi."` UZS\n1 YANDEX RUBL = `".$ya."` UZS\n1 WMZ = `".$wmzo."` UZS";
rg('sendmessage', $cid, $mm, $rez);

$db->exec("UPDATE users SET geo='#' WHERE user_id='".$cid."' ");
}
 if ($dat == "rezerv") {
	$uzsZax = get('byudjet/qiwiuzs.rg') + get('byudjet/wmzuzs.rg') + get('byudjet/yandexuzs.rg');
if(in_array($chid, $admin)) {
	$oo = "*".til(rezirv)."*\n🇺🇿 QIWI SO'M = `".get('byudjet/qiwiuzs.rg')."` UZS\n🇺🇿 YANDEX SO'M = `".get('byudjet/yandexuzs.rg')."` UZS\n🇺🇿 WMZ SO'M = `".get('byudjet/wmzuzs.rg')."` UZS\n🇷🇺 QIWI RUBL = `".get('byudjet/qiwi.rg')."` RUB\n🇷🇺 YANDEX RUBL = `".get('byudjet/yandex.rg')."` RUB\n🇺🇸 WEBMONEY WMZ = `".get('byudjet/wmz.rg')."` USD\n🇺🇿 1XBET UZS = `".get('byudjet/xbetuzs.rg')."` UZS";

} else {
$oo = "*".til(rezirv)."*\n🇺🇿 UZB SO'M = `".$uzsZax."` UZS\n🇷🇺 QIWI RUBL = `".get('byudjet/qiwi.rg')."` RUB\n🇷🇺 YANDEX RUBL = `".get('byudjet/yandex.rg')."` RUB\n🇺🇸 WEBMONEY WMZ = `".get('byudjet/wmz.rg')."` USD\n🇺🇿 1XBET UZS = `".get('byudjet/xbetuzs.rg')."` UZS";
}

rg('editMessageText', $chid, $oo, json_encode(['inline_keyboard'=>[[['text'=>til(kkurs), 'callback_data'=>"kursval"]]]]), $update->callback_query->message->message_id);
}
if ($dat == "kursval") {
$rez = json_encode(['inline_keyboard'=>[[['text'=>til(rezerv), 'callback_data'=>"rezerv"]]]]);
$mm = til(prodaj)."\n1 QIWI RUBL = `".$qiv."` UZS\n1 YANDEX RUBL = `".$yan."` UZS\n1 WMZ = `".$wmzz."` UZS\n1 1XBET UZS = `".$foiz."%`\n\n".til(pokup)."\n1 QIWI RUBL = `".$qi."` UZS\n1 YANDEX RUBL = `".$ya."` UZS\n1 WMZ = `".$wmzo."` UZS";
rg('editMessageText', $chid, $mm, $rez, $mid);
}
include 'refe.php';//REFERAL##########################################


if($tex == til(istoriya)) {
$mez = json_encode(['one_time_keyboard'=>true, 'resize_keyboard'=>true,
'keyboard'=>[[['text'=>til(my)],['text'=>til(obshiy)]],[['text'=>til(menu)]]]]);
rg('sendmessage', $cid, til(razdel), $mez);
$db->exec("UPDATE users SET geo='#' WHERE user_id='".$cid."' ");
//$db->exec("UPDATE obmen SET otype='', btype='' WHERE cid='".$cid."' AND sts = 'loading' ");
 }
if($tex == til(my)) {
$co = $db->queryValue('SELECT COUNT (*) FROM obmen WHERE cid = "'.$cid.'" AND (sts = "success" OR sts = "tekshiruv" OR sts = "otmen") ');
$my = $db->queryRows('SELECT * FROM obmen WHERE cid = "'.$cid.'" AND (sts = "success" OR sts = "tekshiruv" OR sts = "otmen") ORDER BY time DESC LIMIT 20');
$i = 0;
foreach($my as $dy) {
$sts = str_replace('tekshiruv', til(prover), $dy['sts']);
$sts = str_replace('success', til(tulandi), $sts);
$sts = str_replace('otmen', til(tulanmadi), $sts);

$mi = "*ID: ".$dy['id']."\n".til(berish)." ".$dy['berish']." ".$dy['btype']."\n".til(olish)." ".$dy['olish']." ".$dy['otype']."\n".til(time)." ".date('d.m.y / H:i:s', $dy['time'])."\n".til(sts)." ".$sts."*";
rg('sendmessage', $cid, $mi);
$i++;
} $hi = til(posledniy); $hi = str_replace('{co}', $i, $hi);
rg('sendmessage', $cid, "*".$hi."*");
}
if ($tex == til(obshiy)) {
$i = json_encode(['inline_keyboard'=>[[['text'=>til(ulan), 'url'=>"t.me/obmenniy"]]]]);
$ne = til(vseoperat);
rg('sendmessage', $cid, $ne, $i);
}

if ($tex == til(aloqa)) {
$i = json_encode(['inline_keyboard'=>[[['text'=>til(typing), 'url'=>"t.me/myobmeuz"]]]]);
$ne = til(svyaz);
$ne = str_replace('{nomer}', $aloqa, $ne);
rg('sendmessage', $cid, $ne, $i);
$db->exec("UPDATE users SET geo='#' WHERE user_id='".$cid."' ");
//$db->exec("UPDATE obmen SET otype='', btype='' WHERE cid='".$cid."' AND sts = 'loading' ");
}
if($tex == til(biz)) {
rg('sendmessage', $cid, "*".$company."* ".til(comp)." ".$site."\n\n".til(dasturchi));
$db->exec("UPDATE users SET geo='#' WHERE user_id='".$cid."' ");
//$db->exec("UPDATE obmen SET otype='', btype='' WHERE cid='".$cid."' AND sts = 'loading' ");
}

} else {

if ($em['geo'] == "start") {

$remove = json_encode(array('remove_keyboard' => true));
rg('sendmessage', $cid, til(fio), $remove);
sleep(2);
$db->exec("UPDATE users SET geo='fio' WHERE user_id='".$cid."' ");
}
}

$otziv = json_encode(['inline_keyboard'=>[[['text'=>"Tarix / История", 'url'=>"t.me/obmenniy"]]]]);
if($dat == "succes") {
preg_match_all('|-(.*)-|Uis', json_encode($call->message->text), $bu);
preg_match_all('|"first_name":"(.*)",|Uis', json_encode($call->message->entities), $nik);
$ka = $db->queryRow('SELECT * FROM obmen WHERE cid = "'.$bu[1][0].'" AND sts = "tekshiruv" ');
$use = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$bu[1][0].'" ');

$xabar = $call->message->text."

✅ Bajarilgan";

bot('editMessageText', ['chat_id' => $call->message->chat->id, 'text' => $xabar, 'message_id' => $call->message->message_id, 'entities'=>json_encode($call->message->entities)]); 
bot('sendMessage', ['chat_id'=>$bu[1][0], 'text'=>"✅* ".$ka['olish']." ".$ka['otype']." Hisobingizga tushirildi 🇺🇿\n\n✅ ".$ka['olish']." ".$ka['otype']." Был зачислен на ваш счет 🇷🇺*", 'parse_mode'=>"markdown", 'reply_markup'=>$otziv]);
		

$db->exec("UPDATE obmen SET sts='success' WHERE cid='".$bu[1][0]."' AND sts = 'tekshiruv' ");

///####REZERV ZAHIRANI TAXRIRLASH#####
if($ka['otype'] == "UZBSO'M" && $ka['btype'] == "QIWI RUBL") {
$miq = $ka['olish']; $uzc = get('byudjet/qiwiuzs.rg'); $minus = $uzc - $miq; file_put_contents('byudjet/qiwiuzs.rg', $minus);
$miqZ = $ka['berish']; $qiwi = get('byudjet/qiwi.rg'); $plus = $qiwi + $miqZ; file_put_contents('byudjet/qiwi.rg', $plus); 

}
if ($ka['otype'] == "UZBSO'M" && $ka['btype'] == "YANDEX RUBL") {
	$miqY = $ka['olish']; $uzc = get('byudjet/yandexuzs.rg');  $minus = $uzc - $miqY; file_put_contents('byudjet/yandexuzs.rg', $minus);
$miq = $ka['berish']; $yande = get('byudjet/yandex.rg'); $plus = $yande + $miq; file_put_contents('byudjet/yandex.rg', $plus); 

}
if ($ka['otype'] == "UZBSO'M" && $ka['btype'] == "WMZ") {
$miqW = $ka['olish']; $uzc = get('byudjet/wmzuzs.rg'); $minus = $uzc - $miqW; file_put_contents('byudjet/wmzuzs.rg', $minus);
$miq = $ka['berish']; $wmz = get('byudjet/wmz.rg'); $plus = $wmz + $miq; file_put_contents('byudjet/wmz.rg', $plus);
}


	if($ka['otype'] == "QIWI RUBL" && $ka['btype'] == "UZBSO'M") {
$miq = $ka['olish']; $qiw = get('byudjet/qiwi.rg'); $minus = $qiw - $miq; file_put_contents('byudjet/qiwi.rg', $minus);
$miqZ = $ka['berish']; $uzc = get('byudjet/qiwiuzs.rg'); $plus = $uzc + $miqZ; file_put_contents('byudjet/qiwiuzs.rg', $plus);

}

if($ka['otype'] == "YANDEX RUBL" && $ka['btype'] == "UZBSO'M") {
$miq = $ka['olish']; $yand = get('byudjet/yandex.rg'); 
 $minus = $yand - $miq; file_put_contents('byudjet/yandex.rg', $minus); 
$miqY = $ka['berish']; $uzc = get('byudjet/yandexuzs.rg'); $plus = $uzc + $miqY; file_put_contents('byudjet/yandexuzs.rg', $plus);

} 

if ($ka['otype'] == "WMZ" && $ka['btype'] == "UZBSO'M") {
$miq = $ka['olish']; $wmz = get('byudjet/wmz.rg'); $minus = $wmz - $miq; file_put_contents('byudjet/wmz.rg', $minus); 
$miqWZ = $ka['berish']; $uzc = get('byudjet/wmzuzs.rg'); $plus = $uzc + $miqWZ; file_put_contents('byudjet/wmzuzs.rg', $plus);
}
if($ka['otype'] == "1XBET UZS") {
$miq = $ka['olish']; $qiw = get('byudjet/xbetuzs.rg'); $minus = $qiw - $miq; file_put_contents('byudjet/xbetuzs.rg', $minus); }
//REFERALGA PLUS
$olsh = $ka['otype'];
$ber= $ka['btype'];
$b = $ka['berish'];
$o = $ka['olish'];
$fid =$ka['cid'];
$r = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$fid.'" ');
if($ber == "UZBSO'M") {

$w = str_replace('YANDEX RUBL', $ya, $olsh);
$w = str_replace('WMZ', $wmzo, $w);
$w = str_replace('QIWI RUBL', $qi, $w);


$f = $o * $w;
$a = $b - $f;
$g = $a * 5 / 100;//referaliski
$ceshbek = $a * 3 / 100;//cashback
$db->exec("UPDATE users SET hisob = hisob + '".$g."'  WHERE user_id='".$r['ref']."' ");
$db->exec("UPDATE users SET hisob = hisob + '".$ceshbek."'  WHERE user_id='".$bu[1][0]."' ");

}

///ISBOT KANAL
$ism = bot('getchat', ['chat_id'=>$ka['cid']])->result->first_name;
$vtype = str_replace(["QIWI RUBL", "YANDEX RUBL", "WMZ", "UZBSO'M"], ["RUBL", "RUBL", "USD", "SO'M"], $ka['otype']);
$kanalTo = $db->queryRow('SELECT * FROM obmen WHERE cid = "'.$bu[1][0].'" AND sts = "success" ');

$isbot = "*🆔: {$ka['id']}
👤: {$ism}
🔀: {$ka['btype']}➡️{$ka['otype']}
🔎 Статус: ✅
📝: ".date('d.m.y H:i', $ka['time'])."
✅: ".date('d.m.y H:i', time())."
📥: {$ka['olish']} $vtype*";


rg('sendmessage', $isbotk, $isbot);
}
if ($dat == "neplachen") {
preg_match_all('|-(.*)-|Uis', json_encode($call->message->text), $bu);
$ka = $db->queryRow('SELECT * FROM obmen WHERE cid = "'.$bu[1][0].'" AND sts = "tekshiruv" ');
$use = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$bu[1][0].'" ');
$xabar = $call->message->text."

❌ Bekor qilingan";

bot('editMessageText', ['chat_id' => $chid, 'text' => $xabar, 'message_id' => $mid, 'entities'=>json_encode($call->message->entities)]); 
rg('sendmessage', $bu[1][0], "❌* ".$ka['olish']." ".$ka['otype']." Siz pulni tashlamadingiz 🇺🇿\n\n❌ ".$ka['olish']." ".$ka['otype']." Вы не бросали деньги 🇷🇺*", $otziv);
$db->exec("UPDATE obmen SET sts='otmen' WHERE cid='".$bu[1][0]."' AND sts = 'tekshiruv' ");
}
if($dat == "ban") {
preg_match_all('|-(.*)-|Uis', json_encode($call->message->text), $bu);
$ism = bot('getchat', ['chat_id'=>$bu[1][0]])->result->first_name;
$xabar = "[".$ism."](tg://user?id=".$bu[1][0].") - 🚫 BANLANDI";
rg('editMessageText', $chid, $xabar, $not, $mid);
$db->exec("UPDATE obmen SET sts='otmen' WHERE cid='".$bu[1][0]."' AND sts = 'tekshiruv' ");
$db->exec("UPDATE users SET ban='1' WHERE user_id='".$bu[1][0]."' ");
}


if ($em['geo'] == "fio") {
$ku = explode(' ', $tex);
if (strlen($ku[1]) > 3) {
$nomr = json_encode(['resize_keyboard'=>true, 'keyboard' => [[["text"=>"⏳ ".til(vzitka),'request_contact' =>true],],]]);
rg('sendmessage', $cid, til(vizet), $nomr);
 $db->exec("UPDATE users SET fio='".$ku[0]." ".$ku[1]." ".$ku[2]."', geo='raqam' WHERE user_id='".$cid."' ");
} else {
rg('sendmessage', $cid, til(ismi));
}}

if ($em['geo'] == "raqam") {
if ($message->contact) {
//$nu = explode('+99', $message->contact->phone_number);

rg('sendmessage', $cid, til(spasiba), $menu);
$db->exec("UPDATE users SET nomer='".$message->contact->phone_number."', geo='#' WHERE user_id='".$cid."' ");
}
}

if(in_array($cid, $admin)) {
if(mb_stripos($tex,"##") !== false) {
$mid = $message->reply_to_message->message_id;

file_put_contents('rass.txt', json_encode($update));

bot('sendmessage', ['chat_id'=>$cid, 'text'=>"*Tayyor:* /Yubor Yuborishga tayyor", 'parse_mode'=>"markdown"]);
// строка, которую будем записывать
$texti = file_get_contents('txt.txt');
 
$fp = fopen("cron.php", "w");
 
fwrite($fp, $texti);
 
fclose($fp);
}
if ($tex == "/Yubor") {
file_put_contents('next.txt', '0');
file_put_contents('stop.txt', '0');
bot('sendmessage', ['chat_id'=>"652903849", 'text'=>"Habar yetkazilmoqda..."]);
file_get_contents('http://myobmenuz.cf/cron.php');
}

if(mb_stripos($tex,"qiwi") !== false || mb_stripos($tex,"wmzuzs") !== false || mb_stripos($tex,"yandex") !== false || mb_stripos($tex,"wmz") !== false || mb_stripos($tex,"qiwiuzs") !== false || mb_stripos($tex,"yandexuzs") !== false || mb_stripos($tex,"xbetuzs") !== false) {
$p = preg_split("/[\ ,-]+/", $tex);
if ($p[1] == true && is_numeric($p[2]) == true) {
$xi = "Valyuta: $p[0]
Sotish: ".$p[1]."
Olish: ".$p[2];
rg('sendmessage', $cid, $xi);

$db->exec("UPDATE valyut SET sotish='".$p[1]."', olish='".$p[2]."' WHERE turi='".$p[0]."' ");
} else {
 $z = preg_split("/[\+,-]+/", $tex);
$zz = file_get_contents('byudjet/'.$z[0].'.rg');
$min = explode($z[0]."-", $tex);
$plu = explode($z[0]."+", $tex);
if ($min[1] == true) {
$ZAX = $zz - $z[1];
file_put_contents('byudjet/'.$z[0].'.rg', $ZAX);
rg('sendmessage', $cid, "*✅ ".$z[1]." $z[0] zahiradan ayirib tashlandi*");

	} else if ($plu[1] == true){
$ZAX = $zz + $z[1];
file_put_contents('byudjet/'.$z[0].'.rg', $ZAX);
rg('sendmessage', $cid, "*✅ ".$z[1]." $z[0] zahiraga qo'shildi*");

}

}//kurs taxrirlash
}
	


if(mb_stripos($tex,"/stop") !== false) {
$st = explode('=', $tex);
file_put_contents('off.morgan', $st[1]);
rg('sendmessage', $cid, "*✅ ".$st[1]." -da ochishni unutmang*");
}
if(mb_stripos($tex,"/foiz") !== false) {
$st = explode('=', $tex);
file_put_contents('byudjet/foiz.txt', $st[1]);
rg('sendmessage', $cid, "*✅ ".$st[1]." % qilindi*");
}

if($tex == "/admin") {
$admi = "*Kerakli buyruqlar yodda saqlang:*\n\n◽ Sotish va Olish kursini taxrirlash (namuna:)\n\n`qiwi 150-145`\n\n`wmz 10000-9000`\n\n`yandex 150-145`\n\n◽ Zaxira pullarni taxrirlash (namuna:)\n\n`qiwi+1000 / qiwi-1000\nqiwiuzs+5370 / qiwiuzs-5370\nyandexuzs+7700 / yandexuzs-7700\nwmzuzs+3200 / wmzuzs-3200\nyandex+19000 / yandex-19000\nwmz+50 / wmz-50\nxbetuzs+5377732 / xbetuzs-5377732`\n\n🌍Qo'shimcha funksiyalar:\n/stop=Vaqtincha ish faolyat to'xtatish\n`##` Hammaga yuboriladigan xabarni tayyorlash (рассылка) va /Yubor ni bosib yuborish mumkin";
rg('sendmessage', $cid, $admi);
}



if (mb_stripos($tex, "/tekshir") !==false) {
	$idg = explode('=', $tex)[1];
	$prover = $db->queryRows('SELECT * FROM users WHERE ref = "'.$idg.'" ');
$p = '';
for($i=0; $i<count($prover); $i++) {

	$o_b = $db->queryRows('SELECT * FROM obmen WHERE cid = "'.$prover[$i]['user_id'].'" AND sts = "success" ');
if (count($o_b[0]['sts']) > 0) {
$ob = '';
for($l=0; $l<count($o_b); $l++) {

	$ob .= "` __________________________________`
├ B/O: ".$o_b[$l]['btype']." / ".$o_b[$l]['otype']."
├  ⬆️  ".$o_b[$l]['berish']." ⬇️  ".$o_b[$l]['olish']."
├ ⏰ Sana: ".date('H:i / Y.m.d', $o_b[$l]['time'])."\n";

}

} else {
$ob = "Hali almashuv qilmagan";
}
$p .= "👤* ".$i.")* [".$prover[$i]['user_id']."](tg://user?id=".$prover[$i]['user_id'].") Hisob: ".$prover[$i]['hisob']."
".$ob."\n\n";
}
	rg('sendmessage', $cid, $p);
	}



}//adminstva

if (mb_stripos($tex,"/start ") !== false) {
$od = explode('/start ', $tex);
if($od[1] == $cid) {  if($db->queryValue('SELECT COUNT (*) FROM users WHERE user_id = "'.$cid.'" ') == 0) { $db->exec('INSERT INTO "users" ("user_id")
    VALUES ("'.$cid.'")'); } } else { $refc = $db->queryValue('SELECT COUNT (*) FROM users WHERE user_id = "'.$cid.'" AND ref = "'.$od[1].'" '); 
if($refc == 0) {
if($db->queryValue('SELECT COUNT (*) FROM users WHERE user_id = "'.$cid.'" ') == 0) {
$db->exec('INSERT INTO "users" ("user_id", "ref")
    VALUES ("'.$cid.'", "'.$od[1].'")'); 
 rg('sendmessage', $od[1], "*У вас есть новый реферал / Sizda yangi referal:* [".$message->from->first_name."](tg://user?id=".$cid.") !"); }
}
}
$refe = $db->queryValue('SELECT COUNT (user_id) FROM users WHERE ref = "'.$cid.'" ');//reflarim soni

rg('sendmessage', $cid, "Выберите язык интерфейса💬\n\nInterfeys tilini tanlang", json_encode(['inline_keyboard'=>[[['text'=>"Русский", 'callback_data'=>"ru"],['text'=>"O'zbek tili", 'callback_data'=>"uz"]]]]));
 
}
?>