﻿<?php
$a = "⏫"; $v = "⏬";
if ($dat == "yandexb") {

$yan = json_encode(['inline_keyboard'=>[[['text'=>$a." UZBSO'M", 'callback_data'=>"uzcardb"],['text'=>$v." UZBSO'M", 'callback_data'=>"uzcardo"]],[['text'=>$a." WMZ", 'callback_data'=>"wmzb"],['text'=>"▫️", 'callback_data'=>"wmzo"]],[['text'=>"✅".$a." YANDEX RUBL", 'callback_data'=>"yandexb"],['text'=>"▫️", 'callback_data'=>"#"]],[['text'=>$a." QIWI RUBL", 'callback_data'=>"qiwib"],['text'=>"▫️", 'callback_data'=>"#"]],]]);
rg('editMessageText', $chid, til(obmenit), $yan, $mid);
$obm = $db->queryValue('SELECT COUNT (*) FROM obmen WHERE cid = "'.$chid.'" AND sts = "loading" ');
if ($obm == 0) {
$db->exec('INSERT INTO "obmen" ("cid", "btype", "sts")
    VALUES ("'.$chid.'", "YANDEX RUBL", "loading")'); } else { $db->exec("UPDATE obmen SET btype='YANDEX RUBL' WHERE cid='".$chid."' AND sts = 'loading' ");
}
} else if ($dat == "qiwib") {
$yan = json_encode(['inline_keyboard'=>[[['text'=>$a." UZBSO'M", 'callback_data'=>"uzcardb"],['text'=>$v." UZBSO'M", 'callback_data'=>"uzcardo"]],[['text'=>$a." WMZ", 'callback_data'=>"wmzb"],['text'=>"▫️", 'callback_data'=>"#"]],[['text'=>$a." YANDEX RUBL", 'callback_data'=>"yandexb"],['text'=>"▫️", 'callback_data'=>"#"]],[['text'=>"✅".$a." QIWI RUBL", 'callback_data'=>"qiwib"],['text'=>"▫️", 'callback_data'=>"#"]],]]);
rg('editMessageText', $chid, til(obmenit), $yan, $mid);
$obm = $db->queryValue('SELECT COUNT (*) FROM obmen WHERE cid = "'.$chid.'" AND sts = "loading" ');
if ($obm == 0) {
$db->exec('INSERT INTO "obmen" ("cid", "btype", "sts")
    VALUES ("'.$chid.'", "QIWI RUBL", "loading")'); } else { $db->exec("UPDATE obmen SET btype='QIWI RUBL' WHERE cid='".$chid."' AND sts = 'loading' ");
}
} else if ($dat == "uzcardb") {

$yan  = json_encode(['inline_keyboard'=>[[['text'=>"✅".$a." UZBSO'M", 'callback_data'=>"uzcardb"],['text'=>"▫️", 'callback_data'=>"#"]],[['text'=>$a." WMZ", 'callback_data'=>"wmzb"],['text'=>$v." WMZ", 'callback_data'=>"wmzo"]],[['text'=>$a." YANDEX RUBL", 'callback_data'=>"yandexb"],['text'=>$v." YANDEX RUBL", 'callback_data'=>"yandexo"]],[['text'=>$a." QIWI RUBL", 'callback_data'=>"qiwib"],['text'=>$v." QIWI RUBL", 'callback_data'=>"qiwio"]],[['text'=>"▫️", 'callback_data'=>"xbetusdb"],['text'=>$v." 1XBET UZS", 'callback_data'=>"xbetuzso"]]]]);

rg('editMessageText', $chid, til(obmenit), $yan, $mid);
$obm = $db->queryValue('SELECT COUNT (*) FROM obmen WHERE cid = "'.$chid.'" AND sts = "loading" ');
if ($obm == 0) {
$db->exec('INSERT INTO "obmen" ("cid", "btype", "sts")
    VALUES ("'.$chid.'", "UZBSO\'M", "loading")'); } else { $db->exec('UPDATE obmen SET btype="UZBSO\'M" WHERE cid="'.$chid.'" AND sts = "loading" ');
}
} else if ($dat == "wmzb") {
$yan = json_encode(['inline_keyboard'=>[[['text'=>$a." UZBSO'M", 'callback_data'=>"uzcardb"],['text'=>$v." UZBSO'M", 'callback_data'=>"uzcardo"]],[['text'=>"✅".$a." WMZ", 'callback_data'=>"wmzb"],['text'=>"▫️", 'callback_data'=>"#"]],[['text'=>$a." YANDEX RUBL", 'callback_data'=>"yandexb"],['text'=>"▫️", 'callback_data'=>"#"]],[['text'=>$a." QIWI RUBL", 'callback_data'=>"qiwib"],['text'=>"▫️", 'callback_data'=>"#"]],]]);
rg('editMessageText', $chid, til(obmenit), $yan, $mid);
$obm = $db->queryValue('SELECT COUNT (*) FROM obmen WHERE cid = "'.$chid.'" AND sts = "loading" ');
if ($obm == 0) {
$db->exec('INSERT INTO "obmen" ("cid", "btype", "sts")
    VALUES ("'.$chid.'", "WMZ", "loading")'); } else { $db->exec("UPDATE obmen SET btype='WMZ' WHERE cid='".$chid."' AND sts = 'loading' ");
}

 
} 
///OLISH TUGMALAR⏫⏬

if ($dat == "qiwio" || $dat == "yandexo" || $dat == "uzcardo" || $dat == "xbetuzso" || $dat == "wmzo") {
if ($dat == "qiwio") { $otype = "QIWI RUBL"; } else if($dat == "yandexo") { $otype = "YANDEX RUBL"; } else if($dat == "uzcardo") { $otype = "UZBSO'M"; } else if($dat == "wmzo") { $otype = "WMZ";  } else if($dat == "xbetuzso") { $otype = "1XBET UZS"; }

$db->exec('UPDATE obmen SET otype="'.$otype.'", berish="", olish="" WHERE cid="'.$chid.'" AND sts = "loading" ');
$q = $db->queryRow('SELECT * FROM obmen WHERE cid = "'.$chid.'" AND sts = "loading" ');
$us = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$chid.'" ');
if ($q['btype'] == "YANDEX RUBL") { $ber = "*YANDEX: ".$us['yandex']."*"; } else if ($q['btype'] == "UZBSO'M") { $ber = "*CARD: ".$us['uzcard']."*"; } else if ($q['btype'] == "QIWI RUBL") { $ber = "*QIWI: ".$us['qiwi']."*"; } else if ($q['btype'] == "WMZ") {$ber = "*WMZ: ".$us['wmz']."*"; } 

if ($q['otype'] == "QIWI RUBL") { $ol = "*QIWI: ".$us['qiwi']."*"; } else if ($q['otype'] == "YANDEX RUBL") { $ol = "*YANDEX: ".$us['yandex']."*"; } else if ($q['otype'] == "UZBSO'M") { $ol = "*CARD: ".$us['uzcard']."*"; } else if($q['otype'] == "WMZ") { $ol = "*WMZ: ".$us['wmz']."*"; } else if($q['otype'] == "1XBET UZS") { $ol = "*1XBET UZS: ".$us['xbetuzs']."*"; } 

$tugma = json_encode(['inline_keyboard'=>[[['text'=>til(ber)." ".$q['btype'], 'callback_data'=>"bqiymat"]],[['text'=>til(ol)." ".$q['otype'], 'callback_data'=>"oqiymat"]],[['text'=>til(otmen), 'callback_data'=>"otmen"]]]]);
$qo = til(zayom)."\nID: `".$q['id']."`\n".til(berish)." `*`".$q['btype']."\n".til(olish)." `*`".$q['otype']."\n".$ber."\n".$ol;

	if (!empty($q['btype'])) {
$da = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$chid.'" ');
$qiw = str_replace('o', '', $dat);  
$qiw = str_replace('xbetuzs', 'xbetuzs', $qiw);

$hisobb = str_replace('QIWI RUBL', 'qiwi', $q['btype']);
$hisobb = str_replace('YANDEX RUBL', 'yandex', $hisobb);
$hisobb = str_replace("UZBSO'M", "uzcard", $hisobb);
$hisobb = str_replace('WMZ', 'wmz', $hisobb);
$hisobb = str_replace('1XBET UZS', 'xbetuzs', $hisobb);//BERISH SCHET RAQAM

if(!empty($da[$qiw] && $da[$hisobb])) {

/* if ($dat == "uzcardo" || $dat == "xbetuzso") {
rg('deleteMessage', $chid, true, true, $mid);
rg('sendmessage', $chid, $qo, $tugma); }*/

//} else  {
 $qiso = str_replace('o', '', $dat);
$money = $db->queryRow('SELECT * FROM obmen WHERE cid = "'.$chid.'" AND sts = "loading" ');
$uzM = str_replace(["QIWI RUBL", "YANDEX RUBL", "WMZ"], ["qiwiuzs", "yandexuzs", "wmzuzs"], $money['btype']);

$qiso = str_replace('uzcard', $uzM, $qiso);
$qiso = str_replace('xbetuzs', 'xbetuzs', $qiso);
if ($qiso == "qiwi" || $qiso == "yandex") { $pulbormi = get('byudjet/'.$qiso.'.rg') > $rub_min; }else if ($qiso == $uzM || $qiso == "xbetuzs") { $pulbormi = get('byudjet/'.$qiso.'.rg') > $sum_min; } else
if ($qiso == "wmz") { $pulbormi = get('byudjet/'.$qiso.'.rg') > $dollir_min; } 

if ($pulbormi) {
rg('deleteMessage', $chid, true, true, $mid);
rg('sendmessage', $chid, $qo, $tugma);
} else { rg('deleteMessage', $chid, true, true, $mid);
bot('answerCallbackQuery',
 ['callback_query_id'=>$call->id, 'text' => til(tugadi), 'show_alert'=>true]); }//##pul tugadi okasi##
////}//4tasi saytdan

} else {//bazadan danniy tekshir
rg('deleteMessage', $chid, true, true, $mid);
bot('answerCallbackQuery',
 ['callback_query_id'=>$call->id, 'text' => til(info_kirit), 'show_alert'=>true]);
}
} else {
bot('answerCallbackQuery',
 ['callback_query_id'=>$call->id, 'text' => til(tanla)]);
}
}



if ($dat == "bqiymat") {
rg('deleteMessage', $chid, true, true, $mid);
$b = $db->queryRow('SELECT * FROM obmen WHERE cid = "'.$chid.'" AND sts = "loading" ');
if ($b['btype'] == "WMZ") {//wmr/qiwiuz/qiwiru/beeline/uzcard/humo
$tip = $b['otype'];

if ($tip == "UZBSO'M") {
$uzs = str_replace("UZBSO'M", "wmzuzs", $tip);

$m = get('byudjet/'.$uzs.'.rg') / $wmzo;
$t = til(sum_yoz)." ".$b['btype']."\n".til(min)." `".$dollir_min."` USD\n".til(max)." `".$m."` USD"; } 
} else if($b['btype'] == "YANDEX RUBL") {//ucard/beeline/humo
$tipi = $b['otype'];
if($tipi == "UZBSO'M") {
$uzs = str_replace("UZBSO'M", "yandexuzs", $tipi);

$m = get('byudjet/'.$uzs.'.rg') / $ya;
$t = til(sum_yoz)." ".$b['btype']."\n".til(min)." `".$rub_min."` RUB\n".til(max)." `".$m."` RUB"; } 
} else if($b['btype'] == "QIWI RUBL") {//UZCARD/WMZ/
$typ = $b['otype'];
if ($typ == "UZBSO'M") {
$uzs = str_replace("UZBSO'M", "qiwiuzs", $typ);

$m = get('byudjet/'.$uzs.'.rg') / $qi;
$t = til(sum_yoz)." ".$b['btype']."\n".til(min)." `".$rub_min."` RUB\n".til(max)." `".$m."` RUB"; } 
} else if ($b['btype'] == "UZBSO'M" && $b['otype'] == "QIWI RUBL" || $b['otype'] == "YANDEX RUBL" || $b['otype'] == "WMZ" || $b['otype'] == "1XBET UZS") {
$kursi = str_replace('QIWI RUBL', $qiv, $b['otype']);
$kursi = str_replace('YANDEX RUBL', $yan, $kursi);
$kursi = str_replace('WMZ', $wmz, $kursi);

$type = str_replace('QIWI RUBL', 'qiwi', $b['otype']);
$type = str_replace('YANDEX RUBL', 'yandex', $type);
$type = str_replace('WMZ', 'wmz', $type);
$type = str_replace('1XBET UZS', 'xbetuzs', $type);
if ($type == "wmz") {
$m = get('byudjet/'.$type.'.rg') * $kursi;
$t = til(sum_yoz)." ".$b['btype']."\n".til(min)." `".$wmzmin."` UZS\n".til(max)." `".$m."` UZS";
} else if ($type == "xbetuzs") {
$m = get('byudjet/xbetuzs.rg');
$t = til(sum_yoz)." ".$b['btype']."\n".til(min)." `".$sum_min."` UZS\n".til(max)." `".$m."` UZS";
} else {
$m = get('byudjet/'.$type.'.rg') * $kursi; 
$t = til(sum_yoz)." ".$b['btype']."\n".til(min)." `".$sum_min."` UZS\n".til(max)." `".$m."` UZS"; }//######UZCARD / HUMO BERIB BARCHASINI SOTIB OLISH 
 
}

rg('sendmessage', $chid, $t);
$db->exec("UPDATE users SET geo='otdachi' WHERE user_id='".$chid."' ");//otdachi summa kiritish
}

if ($dat == "oqiymat") {
rg('deleteMessage', $chid, true, true, $mid);
$b = $db->queryRow('SELECT * FROM obmen WHERE cid = "'.$chid.'" AND sts = "loading" ');
if ($b['otype'] == "UZBSO'M" || $b['otype'] == "1XBET UZS") {
$uzm = ("QIWI RUBL" == $b['btype']) ? 'qiwiuzs' : '';
$uzv = str_replace(["QIWI RUBL", "YANDEX RUBL", "WMZ"], ["qiwiuzs", "yandexuzs", "wmzuzs"], $b['btype']);
$uzm = str_replace('1XBET UZS', 'xbetuzs', $b['otype']);
$uzm = str_replace("UZBSO'M", $uzv, $uzm);
$t = til(summ_yoz)." ".$b['otype']."\n".til(min)." `".$sum_min."` UZS\n".til(max)." `".get('byudjet/'.$uzm.'.rg')."` UZS"; } else if ($b['otype'] == "QIWI RUBL" || $b['otype'] == "YANDEX RUBL") {
$tipi = str_replace('QIWI RUBL', 'qiwi', $b['otype']);
$tipi = str_replace('YANDEX RUBL', 'yandex', $tipi);

$t = til(summ_yoz)." ".$b['otype']."\n".til(min)." `".$rub_min."` RUB\n".til(max)." `".get('byudjet/'.$tipi.'.rg')."` RUB"; } else if ($b['otype'] == "WMZ") {
$tr = str_replace('WMZ', 'wmz', $b['otype']);
$t = til(summ_yoz)." ".$b['otype']."\n".til(min)." `".$dollir_min."` USD\n".til(max)." `".get('byudjet/'.$tr.'.rg')."` USD"; } 


rg('sendmessage', $chid, $t);
$db->exec("UPDATE users SET geo='poluchi' WHERE user_id='".$chid."' ");//получения summa kiritish
}

include 'otdachi.php';//BERISH//OLISH QIYMATI



if ($dat == "tulash") {
$tp = $db->queryRow('SELECT * FROM obmen WHERE cid = "'.$chid.'" AND sts="loading" ');
if ($tp['btype'] == "UZBSO'M") {
$tul = til(tulov)."\n\n".til(uzcard)."\n".til(plata)."\n\n".til(uzcardv); 
$tula = str_replace("{hisob}", "`".get('byudjet/uzcard.txt')."`", $tul);
$tula = str_replace("{sena} {tip}", "".$tp['berish']." UZS", $tula);
$hisob = get('byudjet/uzcard.txt');
} else if ($tp['btype'] == "QIWI RUBL") {
$scet = str_replace('QIWI RUBL ru', 'qiwiru', $tp['btype']); $scet = str_replace('QIWI RUBL', 'qiwi', $scet);
$tul = til(tulov)."\n\n".til(qiwi)."\n".til(plata); 
$tula = str_replace("{hisob}", "`".get('byudjet/'.$scet.'.txt')."`", $tul);
$tula = str_replace("{sena} {tip}", "".$tp['berish']." QIWI RUBL", $tula);
$hisob = file_get_contents('byudjet/'.$scet.'.txt');
} else if ($tp['btype'] == "YANDEX RUBL") {
$tul = til(tulov)."\n\n".til(yandex)."\n".til(plata); 
$tula = str_replace("{hisob}", "`".get('byudjet/yandex.txt')."`", $tul);
$tula = str_replace("{sena} {tip}", "".$tp['berish']." YANDEX RUBL", $tula); 
$hisob = get('byudjet/yandex.txt');
} else if ($tp['btype'] == "WMZ") {
$tul = til(tulov)."\n\n".til(wmr)."\n".til(izohga)."\n".til(plata); 
$tula = str_replace("{hisob}", "`".get('byudjet/wmz.txt')."`", $tul);
$tula = str_replace("{sena} {tip}", "".$tp['berish']." WMZ", $tula); 
$hisob = get('byudjet/wmz.txt');

} 

$knop = json_encode(['inline_keyboard'=>[[['text'=>til(tuladim), 'callback_data'=>"plachen"]],[['text'=>til(otmen), 'callback_data'=>"otmen"]]]]);
rg('deleteMessage', $chid, true, true, $mid);

rg('sendmessage', $chid, $hisob);
rg('sendmessage', $chid, $tula, $knop);
$db->exec("UPDATE users SET geo='plata' WHERE user_id='".$chid."' ");
}

if ($dat == "plachen") {
$colu = $db->queryValue('SELECT COUNT (DISTINCT(otype)) FROM obmen WHERE cid="'.$chid.'" AND sts = "loading" ');
$col = $db->queryRow('SELECT * FROM obmen WHERE cid = "'.$chid.'" AND sts = "loading" ');
if (!empty($col['berish']) && !empty($col['otype'])) {


$db->exec("UPDATE obmen SET time='".time()."', sts='tekshiruv' WHERE cid='".$chid."' AND sts='loading' ");

rg('deleteMessage', $chid, true, true, $mid);
$ka = $db->queryRow('SELECT * FROM obmen WHERE cid = "'.$chid.'" AND sts = "tekshiruv" ');
$use = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$chid.'" ');
$za = "ID: ".$ka['id']."\n".til(time)." ".date('d.m.y / H:i:s', $ka['time'])."\n\n".til(javobni_kut);
rg('sendmessage', $chid, $za);
//adminga yubor
$qk=json_encode(['inline_keyboard'=>[[['text'=>"✅ Tasdiqlash", 'callback_data'=>"succes"]],[['text'=>"❌ Bekor qilish", 'callback_data'=>"neplachen"]],[['text'=>"🚫 Ban berish", 'callback_data'=>"ban"]]]]);
if ($ka['otype'] == "QIWI RUBL") { $oCard = "🇷🇺 QIWI: `".$use['qiwi']."`";
$oType = "RUB";

$oS = $ka['olish'] * $qi;//qiwi sotish narxi
$foyda = $ka['berish'] - $oS;// Olishdan sotish narxini ayirib foyda chiqarish
$rSom = $foyda * 5 / 100; 

} else if($ka['otype'] == "UZBSO'M") { $oCard = "🇺🇿 CARD: `".$use['uzcard']."`"; $oType = "UZS"; 
} else if($ka['otype'] == "WMZ") { 
$oCard = "🇺🇸 WMZ: `".$use['wmz']."`"; $oType = "USD"; 
$oS = $ka['olish'] * $wmzo;//qiwi sotish narxi
$foyda = $ka['berish'] - $oS;// Olishdan sotish narxini ayirib foyda chiqarish
$rSom = $foyda * 5 / 100; 

} else if($ka['otype'] == "YANDEX RUBL") { 
$oCard = "🇷🇺 YANDEX: `".$use['yandex']."`"; $oType = "RUB"; 
$oS = $ka['olish'] * $ya;//qiwi sotish narxi
$foyda = $ka['berish'] - $oS;// Olishdan sotish narxini ayirib foyda chiqarish
$rSom = $foyda * 5 / 100; 

} else if($ka['otype'] == "1XBET UZS") { $oCard = "🇺🇿 1XBET: `".$use['xbetuzs']."`"; $oType = "UZS";}

if ($ka['btype'] == "QIWI RUBL") { $bCard = "🇷🇺 QIWI: ".$use['qiwi']; $bType = "RUB"; } else if($ka['btype'] == "UZBSO'M") { $bCard = "🇺🇿 CARD: ".$use['uzcard']; $bType = "UZS"; } else if($ka['btype'] == "WMZ") { $bCard = "🇺🇸 WMZ: ".$use['wmz']; $bType = "USD"; } else if($ka['btype'] == "YANDEX RUBL") { $bCard = "🇷🇺 YANDEX: ".$use['yandex']; $bType = "RUB"; } 

$adk = "*✳️ Yangi buyurtma: -$chid-
🆔: {$ka['id']}
🔀: {$ka['btype']}➡️{$ka['otype']}
📤 Berish: {$ka['berish']} $bType
📥 Olish:* `{$ka['olish']}` *$oType*\*
$bCard
$oCard
️♻ [Referal ulushi](tg://user?id=".$use['ref']."): $rSom so'm #ref

✍️ Telegram: [Yozish](tg://user?id=$chid)
📞 Telegram raqami: {$use['nomer']}";

rg('sendmessage', $adm, $adk, $qk);
} else { bot('answerCallbackQuery',
 ['callback_query_id'=>$call->id, 'text' => "Sizdagi bu almashinuv tarixdan o'chib ketgan, Boshidan qayta boshlang !", 'show_alert'=>true]); rg('deleteMessage', $chid, true, true, $mid); }

}




?>