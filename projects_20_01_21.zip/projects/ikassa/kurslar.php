<?php
$kivi = $db->queryRow('SELECT * FROM valyut WHERE turi = "qiwi" ');
$yandeks = $db->queryRow('SELECT * FROM valyut WHERE turi = "yandex" ');
$yan = $yandeks['sotish'];
$qiv = $kivi['sotish'];
$ya = $yandeks['olish'];
$qi = $kivi['olish'];
$wmzz = $db->queryRow('SELECT * FROM valyut WHERE turi = "wmz" ');
$wmz = $wmzz['sotish'];
$wmzo = $wmzz['olish'];
$wmzmin = 1 * $wmz;
$wmz_r = "80";
$wmzrmin =  1 * $wmz_r;


$rub_min = "100";//minimal
$sum_min = "20000";
$dollir_min = "1";//min

$foiz = file_get_contents('byudjet/foiz.txt');
?>



