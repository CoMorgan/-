<?php
$bot_token = '1120423625:AAFZi-pkXOwDKCjrT4Ys2e8Z4asSq2D2JHc';
define('API_KEY','1120423625:AAFZi-pkXOwDKCjrT4Ys2e8Z4asSq2D2JHc');

$company = "QarangBot";//Tashkilot nomi
$kanalimiz="https://t.me/obmenniy";//Rasmiy kanal
$aloqa="998972550506";//Tex podderjka
$isbotk = "@obmenniy";//Isbot zayavka kanali
?>