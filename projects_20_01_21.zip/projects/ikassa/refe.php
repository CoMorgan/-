<?php
$link = "t.me/Qarangbot?start=".$cid;
$hs = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$cid.'" ');
$min = "5000";//minimal 10mingsum


if ($tex == til(ref)) {
$re = json_encode(['inline_keyboard'=>[[['text'=>til(pulyech), 'callback_data'=>"vivesti"],['text'=>til(reflarim), 'callback_data'=>"reflarim"]],[['text'=>til(batafsil), 'callback_data'=>"batafsil"],['text'=>til(ortga), 'callback_data'=>"ortga"]]]]);
$ne = til(hisob)." ".$hs['hisob']." *UZS*\n".til(refing)."\n\n".til(link)." ".$link;
bot('sendmessage', ['chat_id'=>$cid, 'text'=>$ne, 'parse_mode'=>"markdown", 'reply_markup'=>$re]);
$db->exec("UPDATE users SET geo='#' WHERE user_id='".$cid."' ");
//$db->exec("UPDATE obmen SET otype='', btype='' WHERE cid='".$cid."' AND sts='loading' ");
}
$xxs = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$chid.'" ');
if($dat == "vivesti") {
rg('deleteMessage', $chid, true, true, $mid);
if($min > $xxs['hisob']) {

rg('sendmessage', $chid, til(engkam));
} else {
$ye = til(hisob)." ".$xxs['hisob']." *UZS*\n\n".til(yechmoq);
rg('sendmessage', $chid, $ye);
$db->exec("UPDATE users SET geo='refyech' WHERE user_id='".$chid."' ");
}
}
if ($hs['geo'] == "refyech") {
if ($tex < $hs['hisob']+0.1 && $tex > $min-0.1) {
rg('sendmessage', $cid, til(yechildi));
$refi = "*Referal puli*\n
-- ID: •".$cid."•
► ISM: [".$hs['fio']."](tg://user?id=".$hs['user_id'].")
► TEL: ".$hs['nomer']."

► UZCARD: `".$hs['uzcard']."`
►* YECHDI: ".$tex." UZS*";
$mark = json_encode(['inline_keyboard'=>[[['text'=>"✅ Tasdiqlayman", 'callback_data'=>"rsucc"]]]]);
rg('sendmessage', $adm, $refi, $mark);
$db->exec("UPDATE users SET geo='#' WHERE user_id='".$cid."' ");
}
}

if($dat == "rsucc") {
preg_match_all('|•(.*)•|Uis', $call->message->text, $usid);
preg_match_all('|YECHDI: (.*) UZS|Uis', $call->message->text, $balans);
$op = $call->message->text."\n*✅ To'landi*";
rg('editMessageText', $chid, $op, $true, $mid);
rg('sendmessage', $usid[1][0], "*Referal:*\n\n✅ ".$balans[1][0]." UZS To'landi / Оплачена 😉");
///ISBOT KANAL
$ism = bot('getchat', ['chat_id'=>$usid[1][0]])->result->first_name;
$isbot = "*👤:".$ism."
🔀:Вывод партнерских средств
🔎Статус: ✅
✅:".date('d.m.y H:i', time())."
📥: ".$balans[1][0]." UZS*";
rg('sendmessage', $isbotk, $isbot);

$ki = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$usid[1][0].'" ');
$y = $ki['hisob'] - $balans[1][0];
$db->exec("UPDATE users SET hisob='".$y."' WHERE user_id='".$usid[1][0]."' ");
}

if ($dat == "reflarim") {
$co = $db->queryValue('SELECT COUNT (*) FROM users WHERE ref = "'.$chid.'" ');
$rg = til(refson)." ".$co;
rg('deleteMessage', $chid, true, true, $mid);
rg('sendmessage', $chid, $rg);
$db->exec("UPDATE users SET geo='#' WHERE user_id='".$chid."' ");

}

if($dat == "batafsil") {
rg('deleteMessage', $chid, true, true, $mid);
$po = til(hamkor);
rg('sendmessage', $chid, $po);

}
if($dat == "ortga") {
rg('deleteMessage', $chid, true, true, $mid);
rg('sendmessage', $chid, til(menu), $menu);
}
?>