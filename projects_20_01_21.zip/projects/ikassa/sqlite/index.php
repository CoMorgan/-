<?php  
/**
*  Простое использование SQLite
*  см. http://maxsite.org/page/sqlite-pdo
*/

$page = ($p = key($_GET)) ? $p : 'home';

require 'lib/sqlite.php';

try
{
	$db = new Db('db/pages.sqlite');

	// если требуется создать таблицу в сучае её отсутствия
	// $db->exec('	CREATE TABLE IF NOT EXISTS "pages" ("id" INTEGER PRIMARY KEY  NOT NULL  DEFAULT (null) ,"slug" VARCHAR,"text" TEXT,"hits" INTEGER DEFAULT (0) )');
	
	$row = $db->queryRow('SELECT * FROM pages WHERE slug=:page LIMIT 1', array(':page' => $page));

	if ($row)
	{
		echo '<p>' . $row['text'] . '</p>';
		echo '<p>Просмотров: ' . $row['hits'] . '</p>';
		
		$db->update('pages', array('hits' => $row['hits'] + 1), 'id=:id', array(':id' => $row['id']));
	}
}
catch(Exception $e) 
{
	echo '<pre>' . $e->getMessage() . '</pre>';
}

# end of file