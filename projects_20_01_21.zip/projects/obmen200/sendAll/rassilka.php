<?php

unlink('cron.php');
ignore_user_abort(true);

require 'pdo.php';
$db = new Db('../base.sqlite');
 //user id lar massivi
 define('token','811975180:AAFkIKRvB79zWXxGlpkRqphmoNcS36yfBKE');

function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".token.'/'.$method;
    $ch = curl_init($url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
    return json_decode($res);
}

function rass($cid, $m) {

if ($m->message->reply_to_message->voice) {

$send = bot('sendVoice', ['chat_id'=>$cid, 'voice'=>$m->message->reply_to_message->voice->file_id, 'caption'=>$m->message->reply_to_message->caption, 'caption_entities'=>json_encode($m->message->reply_to_message->caption_entities)]);
} else if ($m->message->reply_to_message->document) {
$send = bot('sendDocument', ['chat_id'=>$cid, 'document'=>$m->message->reply_to_message->document->file_id, 'caption'=>$m->message->reply_to_message->caption, 'caption_entities'=>json_encode($m->message->reply_to_message->caption_entities)]);
} else if ($m->message->reply_to_message->audio) {
$send = bot('sendAudio', ['chat_id'=>$cid, 'audio'=>$m->message->reply_to_message->audio->file_id, 'caption'=>$m->message->reply_to_message->caption, 'caption_entities'=>json_encode($m->message->reply_to_message->caption_entities)]);
} elseif ($m->message->reply_to_message->video) {
$send = bot('sendVideo', ['chat_id'=>$cid, 'video'=>$m->message->reply_to_message->video->file_id, 'caption'=>$m->message->reply_to_message->caption, 'caption_entities'=>json_encode($m->message->reply_to_message->caption_entities)]);
} else if ($m->message->reply_to_message->text) {
	if ($m->message->reply_to_message->reply_markup == true) { 
	$send = bot('sendmessage', ['chat_id'=>$cid, 'text'=>$m->message->reply_to_message->text, 'entities'=>json_encode($m->message->reply_to_message->entities), 'reply_markup'=>json_encode($m->message->reply_to_message->reply_markup)]);
	} else { 
	$send = bot('sendmessage', ['chat_id'=>$cid, 'text'=>$m->message->reply_to_message->text, 'entities'=>json_encode($m->message->reply_to_message->entities)]);

	 }
} else if ($m->message->reply_to_message->photo) {

if ($m->message->reply_to_message->reply_markup == true) { 
$send = bot('sendphoto', ['chat_id'=>$cid, 'photo'=>$m->message->reply_to_message->photo[0]->file_id, 'caption'=>$m->message->reply_to_message->caption, 'caption_entities'=>json_encode($m->message->reply_to_message->caption_entities), 'reply_markup'=>json_encode($m->message->reply_to_message->reply_markup)]); 
} else {
$send = bot('sendphoto', ['chat_id'=>$cid, 'photo'=>$m->message->reply_to_message->photo[0]->file_id, 'caption'=>$m->message->reply_to_message->caption, 'caption_entities'=>json_encode($m->message->reply_to_message->caption_entities)]); 

}
}
return $send;
	
}
$n = file_get_contents('next.txt');
$usersoni = $db->column('SELECT COUNT (*) FROM users ');
$usc = $usersoni - $n;
if ($usc >500) { $usc = '500'; } else { $usc = $usc; }


$users = $db->row('SELECT chat_id FROM users LIMIT '.$n.', '.$usc.'');
 


$m=json_decode(file_get_contents('rass.txt'));
$i = 1;
	foreach($users as $us) {
$i++;
if ($i == $usc) {
$p = file_get_contents('next.txt'); $z = $p + $i;
file_put_contents('next.txt', $z);//LIMIT
}
  $mo =  rass($us['chat_id'], $m);
//$mo = bot('sendmessage', ['chat_id'=>"266873587", 'text'=>json_encode($m->message->reply_to_message->reply_markup), 'reply_markup'=>json_encode($m->message->reply_to_message->reply_markup), 'disable_notification'=>"true"]);
if ($mo->ok == true) {
$s = file_get_contents('stop.txt');
$c = $s + 1;
file_put_contents('stop.txt', $c); }
  }
$userlar = $db->column('SELECT COUNT (*) FROM users ');
if (file_get_contents('next.txt') == $userlar) {
$odam = file_get_contents('stop.txt');
bot('sendmessage', ['chat_id'=>"266873587", 'text'=>"*Rassilka yakunlandi*\nYuborildi: $odam ta kishiga\nJami: $userlar kishi", 'parse_mode'=>"markdown"]);
} else {

$cron = file_get_contents('txt.txt'); 
$fp = fopen("cron.php", "w");
fwrite($fp, $cron);
fclose($fp);
sleep(120);
file_get_contents('http://muzmos.cf/sendAll/cron.php');
 }
?>