<?php
if (in_array($chat_id, $admins)) {
	if (stripos($text, "/add") !==false) {
		$channel = explode('=', $text);
		
		$bot->go('sendmessage', ['chat_id'=>$chat_id, 'text'=>$channel[1]." Kanali qo'shildi"]);
		$kanal_on= $db->queryValue('SELECT COUNT (*) FROM channels WHERE channel = "'.$channel[1].'" ');
if ($kanal_on == 0) {
		$db->exec('INSERT INTO "channels" ("channel", "link", "name")
    VALUES ("'.$channel[1].'", "'.$channel[2].'", "'.$channel[3].'")');
	file_put_contents('kanallar.txt', '#'.$channel[1], FILE_APPEND);
	
	}
	}
	
	if ($text == "/kanal") {
			$kanal_spiska = $db->queryRows('SELECT * FROM channels ');
$aue = '';
foreach ($kanal_spiska as $akanal) {
$aue .= '['.$akanal['name'].']('.$akanal['link'].') - ❌ /delete'.$akanal['id'].'

';

}
	$bot->rg('sendmessage', $chat_id, $aue);
	}
	
	if (stripos($text, "/delete") !==false) {
		
		$de = explode('/delete', $text)[1];
		$uchir = $db->queryRow('SELECT * FROM channels WHERE id = "'.$de.'" ')['channel'];
$dele = str_replace('#'.$uchir, '', file_get_contents('kanallar.txt'));
file_put_contents('kanallar.txt', $dele);
$db->exec('DELETE FROM channels WHERE id = "'.$de.'" ');
		
$bot->rg('sendmessage', $chat_id, "O'chirildi");


		}
		if (stripos($text, "/minimal") !==false) {
		
		$de = explode('=', $text)[1];
		file_put_contents('minimal.txt', $de);
$bot->rg('sendmessage', $chat_id, "Minimal yechiladigan so'mma o'zgartirildi: $de");
		}
		
			if (stripos($text, "/refmini") !==false) {
		
		$de = explode('=', $text)[1];
		file_put_contents('mini.txt', $de);
$bot->rg('sendmessage', $chat_id, "Referal uchun beriladigan so'mma o'zgartirildi: $de");
		}		
		if(mb_stripos($tex,"##") !== false) {
$mid = $message->reply_to_message->message_id;

file_put_contents('sendtoall/rass.txt', json_encode($update));

bot('sendmessage', ['chat_id'=>$cid, 'text'=>"*Tayyor:* /Yubor Yuborishga tayyor", 'parse_mode'=>"markdown"]);
// строка, которую будем записывать
$texti = file_get_contents('sendtoall/txt.txt');
 
$fp = fopen("cron.php", "w");
 
fwrite($fp, $texti);
 
fclose($fp);
}
if ($tex == "/Yubor") {
file_put_contents('sendtoall/next.txt', '0');
file_put_contents('sendtoall/stop.txt', '0');
bot('sendmessage', ['chat_id'=>"266873587", 'text'=>"Habar yetkazilmoqda..."]);
file_get_contents('http://domwn.cf/cron.php');
}
		
						}//Admin
		
						
		
?>