<?php

/**
 * Sirojov Mahmud (MoRGaN)
 * 01.04.2019
 * Telegram: @C_MoRGaN
 **/
namespace app;


class TelegramBot {


    public function go($method,$datas=[]){
	
 		$botToken = "1120423625:AAFZi-pkXOwDKCjrT4Ys2e8Z4asSq2D2JHc";
        $url = "https://api.telegram.org/bot".$botToken."/".$method;
     
 $ch = curl_init();
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
        $res = curl_exec($ch);
        if(curl_error($ch)){
            var_dump(curl_error($ch));
        }else{
            return json_decode($res);
        }
    }


    public function getData($data){
        return json_decode(file_get_contents($data), TRUE);
 	}

    //Xabar yuborish uchun @String
    public function sendMessage($type){   
        return $this->go('sendMessage', $type);
    }


    //Rasm yuborish
    public function deleteMessage($type){
        return $this->go('deleteMessage', $type);
    }


    //Notification chiqarish uchun ishlatiladigan function
   public function ACL($callbackQueryId, $text = null, $showAlert = false)
{
     return $this->go('answerCallbackQuery', [
        'callback_query_id' => $callbackQueryId,
        'text' => $text,
        'show_alert'=>$showAlert,
    ]);
}

    public function getChatMember($type){
        return $this->go('getChatMember', $type);
    }

    public function rg($met, $sid, $matn, $markup = false, $md = false) {

        return $this->go($met,[
            'chat_id' => $sid,
            'message_id'=>$md,
            'text' => $matn,
            'parse_mode'=>"markdown",
            'reply_markup'=>$markup,
            'disable_web_page_preview'=>true
        ]);
    }



    public function keyboard($key) {

        return json_encode(['resize_keyboard'=>true,
            'keyboard'=>$key]);

    }
public function phone($phone) 
{
 $phone = str_replace('+', '', trim($phone));
 
 $res = preg_replace(
  array(
   '/(\d{3})(\d{2})(\d{3})(\d{2})(\d{2})/'  
  ), 
  array(
   '$2-$3-$4-$5'
  ), 
  $phone
 );
 
 return $res;
}

public function channel($chat_id) {
//$channel = $db->queryRows('SELECT channel FROM channels');
$channel = explode('#', file_get_contents('kanallar.txt'));
$result = '';
	for($i = 0; $i<count($channel); $i++) {
	$join = $this->getChatMember(['chat_id' =>$channel[$i], 'user_id' =>$chat_id])->result->status;
if ($join == "left") {
$result .= $join." ";
}
}
return $result;
}

}//CLASS CLOSE


?>