<?php
/**
 * Colin Morgan
 * 24.05.2020
 * Telegram: @C_MoRGaN
 **/
require 'sqlite.php';
$db = new Db('users');
require 'class.php';
use app\TelegramBot;
require 'channel.php';

date_default_timezone_set('Asia/Tashkent');

$bot = new TelegramBot;
$kanal = new Channel();


$data = $bot->getData("php://input");

$ism = $data['message']['from']['first_name'] . ' ' . $data['message']['from']['last_name'];
$text = $data['message']['text'];
$message_id = $data['message']['message_id'];

//CALLBACK
$callback = $data['callback_query'];
$callid = $callback['id'];
$cdata = $callback['data'];
$name = $callback['from']['first_name'] . ' ' . $callback['from']['last_name'];
$cmid = $callback['message']['message_id'];
// $chat_id

if ($callback == true) {
    $chat_id = $callback['message']['chat']['id'];
} else {
    $chat_id = $data['message']['chat']['id'];
}

// Asosiy malumotlar

$adm = '266873587';//tasdiqlovchi admin


$link = "https://t.me/Qarangbot?start=" . $chat_id;
$minimal = file_get_contents('minimal.txt'); //minimal yechiladigan summa
$mini = file_get_contents('mini.txt'); //minimal to'lanasigan summa
$min_od_s = $minimal / $mini;//minimal odam soni
$admins = ['266873587', '470912206'];
$user_on = $db->queryValue('SELECT COUNT (*) FROM users WHERE cid = "' . $chat_id . '" ');
$menu = $bot->keyboard([[['text' => "💎 Pul ishlash 💎"]], [['text' => "💳 Balans"], ['text' => "Pul qanday ishlayman ⁉️"]]]);




// Locatsiya
$user_i = $db->queryRow('SELECT * FROM users WHERE cid  = "' . $chat_id . '" ');

if (mb_stripos($text, "/start ") !== false) {
    $ch = substr_count($kanal->tekshir($client, $chat_id), "left");
    if ($ch == 0) {
        if ($user_i['raqam'] == true) {
            $bot->rg('sendmessage', $chat_id, "*Assalom Aleykum pul ishlash botimizga hush kelibsiz*", $menu);
        } else {
            // raqam contact
            $key = $bot->keyboard([[['text' => "📲 Raqam jo'natish", 'request_contact' => true]]]);
            $message = "*Telefon raqamingizni yuboring*";
            $bot->rg('sendmessage', $chat_id, $message, $key);

        }
    }
    $rid = str_replace($chat_id, '', explode('/start ', $text)[1]);
    if ($user_on == 0) {
        $db->exec('INSERT INTO "users" ("cid", "referal", "hisob")
    VALUES ("' . $chat_id . '", "' . $rid . '", "0")');
    }

}

if ($cdata == "tayyor") {
    $ch = substr_count($kanal->tekshir($client, $chat_id), "left");

    if ($ch == 0) {

        $oxirgi_ish = $db->queryRow('SELECT * FROM users WHERE cid  = "' . $chat_id . '" ');
        if ($oxirgi_ish['raqam'] == false) {
            $key = $bot->keyboard([[['text' => "Raqam jo'natish", 'request_contact' => true]]]);
            $message = "*Telefon raqamingizni yuboring*";
            $bot->rg('sendmessage', $chat_id, $message, $key);
            $bot->deleteMessage(['chat_id' => $chat_id, 'message_id' => $cmid]);

        } else {
            $bot->ACL($callid, "Hammasi tayyor! Qanday pul ishlashni o'qing va pullaringizni ishlashni boshlang", true);

            $message = "*Pul ishlashingiz mumkin*";
            $menyu = $bot->keyboard([[['text' => "Referal manzil"]], [['text' => "Balans"], ['text' => "Pul qanday ishlayman"]]]);


            $bot->rg('sendmessage', $chat_id, $message, $menyu);
            $db->exec("UPDATE users SET loc='#' WHERE cid='" . $chat_id . "' ");

        }
    } else {
        $bot->ACL($callid, "❌ Siz hali {$ch}ta kanalga obuna bo'lmagansiz!", true);
        $db->exec("UPDATE users SET loc='#' WHERE cid='" . $chat_id . "' ");

    }
}

$ch = substr_count($kanal->tekshir($client, $chat_id), "left");

if ($ch == 0) {

    if ($text == "/start" || $text == "⬇️ Orqaga") {
        if ($user_i['raqam'] == true) {
            $bot->rg('sendmessage', $chat_id, "*Assalom aleykum pul ishlash botimizga hush kelibsiz*", $menu);
        } else {
            $key = $bot->keyboard([[['text' => "📲 Raqam jo'natish", 'request_contact' => true]]]);
            $message = "*Telefon raqamingizni yuboring*";
            $bot->rg('sendmessage', $chat_id, $message, $key);

        }
        if ($user_on == 0) {
            $db->exec('INSERT INTO "users" ("cid", "hisob")
    VALUES ("' . $chat_id . '", "0")');
        }
    }
    if ($text == "💎 Pul ishlash 💎") {
        $texts = "Pul ishlash uchun ushbu referal manzilingizni do'stlaringizga ulashing:
" . $link;
        $ulash = "https://telegram.me/share/url?url=" . $link . "&text=\nMana shu botga kirib pul ishlang, haqiqiy pullarni to'lashmoqda";
        $inline_key = json_encode(['inline_keyboard' => [[['text' => "📣 Yuborish", 'url' => $ulash]]]]);
        $bot->rg('sendmessage', $chat_id, $texts, $inline_key);
    }
    $b_hisob = $db->queryRow('SELECT * FROM users WHERE cid  = "' . $chat_id . '" ');

    if ($text == "💳 Balans") {
        $reflarim = $db->queryValue('SELECT COUNT (*) FROM users WHERE referal = "' . $chat_id . '" ');
        $pul_yechish = $bot->keyboard([[['text' => "📤 Pul yechish"]], [['text' => "⬇️ Orqaga"]]]);
        $balans = "💰 *hisob: {$b_hisob['hisob']} so'm
👥 Referalar: {$reflarim} kishi*";
        $bot->rg('sendmessage', $chat_id, $balans, $pul_yechish);
    }
    if ($text == "📤 Pul yechish") {
        if ($b_hisob['hisob'] > $minimal - 1) {
            $texs = "*Hisob raqamingizni yozing: 
Click, Paynet..*";
            $bot->rg('sendmessage', $chat_id, $texs, json_encode(
                ['force_reply' => true, 'selective' => false]));
        } else {
            $bot->rg('sendmessage', $chat_id, "*Afsuski sizda hali yechish uchun biroz referallar kamlik qilyapti*");
        }
    }
    if (mb_stripos($data['message']['reply_to_message']['text'], "Click") !== false) {
        $bot->rg('sendmessage', $chat_id, "*Pullaringiz yechildi tez orada hisobingizga tushadi !*", $menu);
        $texs = "ID: $chat_id
▪️Telegram: [#$ism](tg://user?id=$chat_id)
▪️ Raqam: $text
▫️ Yechildi: {$b_hisob['hisob']} so'm
▪️ Ro'yhatdan o'tgan raqami: {$b_hisob['raqam']}";
        $succes = json_encode(['inline_keyboard' => [[['text' => "To'landi", 'callback_data' => "success"]]]]);

        $bot->rg('sendmessage', $adm, $texs, $succes);

        $db->exec("UPDATE users SET hisob='0' WHERE cid='" . $chat_id . "' ");

    }

if ($text == "Pul qanday ishlayman ⁉️") {
	$texts = "Salom foydalanuvchi, bizning bot orqali *qanday pul ishlash* haqida:

1. Avval o'zingiz hamma kanallarga obuna bo'lishingiz shart, va kanallardan aslo chiqib ketmang.
2. Bosh menudan 💎Pul ishlash💎 tugmasini bosib, o'z referral manzilingizni do'stlarga yuboring.
3. Do'stingiz sizning referral manzilingizdan o'tib barcha kanallarga a'zo bo'lganidan so'ng, har bir do'stingizdan sizga 500so'm taqdim etiladi.
4. Pullarni bosh menudagi 💳 Balans tugmasi orqali yechib olishingiz mumkun.

Ogohlantirish!
- Taklif qilgan do'stingiz faqat sizning referral manzilingizdan o'tib to'liq shartlarni bajarsagina pul taqdim etiladi.
- Chet el raqamlaridan do'stlar yig'ib pul ishlash taqiqlanadi.

Hammaga omad!";
$bot->rg('sendmessage', $chat_id, $texts);
	}

    if ($data['message']['contact'] == true) {
        $nomer = $data['message']['contact']['phone_number'];
        if (substr(str_replace('+', '', $nomer), 0, 3) == "998") {

            $menyux = $bot->keyboard([[['text' => "💎 Pul ishlash 💎"]], [['text' => "💳 Balans"], ['text' => "Pul qanday ishlayman ⁉️"]]]);

            $message = "*Shartlarni mufaqqiyatli bajardingiz va sizga 500 so'm miqdorda bonus berildi!*";

            $bot->rg('sendmessage', $chat_id, $message, $menyux);

            $user_inf = $db->queryRow('SELECT * FROM users WHERE cid  = "' . $chat_id . '" ');
            //$odam = $db->queryValue('SELECT COUNT (*) FROM users WHERE referal = "'.$user_inf['referal'].'" ');
            $ref_inf = $db->queryRow('SELECT * FROM users WHERE cid  = "' . $user_inf['referal'] . '" ');

            $mesref = "*Sizga* [$ism](tg://user?id='.$chat_id.') *do'stingiz referal bo'ldi va hisobingiz $mini so'mga oshdi*";
            $bot->rg('sendmessage', $user_inf['referal'], $mesref);
            $mini_sum = $ref_inf['hisob'] + $mini;
            $db->exec("UPDATE users SET raqam='$nomer', 'hisob' = '$mini' WHERE cid='" . $chat_id . "' ");
            $db->exec("UPDATE users SET hisob = '$mini_sum' WHERE cid='" . $user_inf['referal'] . "' ");
        } else {
            $bot->rg('sendmessage', $chat_id, "*Faqat O'zbekiston raqamlari qabul qilinadi*");
        }
    }

    // kanalga azo bo'lmasa
} else {

    if ($text) {
        $oxirgi_ish = $db->queryRow('SELECT * FROM users WHERE cid  = "' . $chat_id . '" ');
        if ($oxirgi_ish['referal'] == true) {
            $name = $bot->go('getchat', ['chat_id' => str_replace('start', '', $oxirgi_ish['referal'])])->result->first_name;

            $message = "*Kanalga a'zo bo'lganingizdan keyin do'stingizga pul tushadi va siz ham pullaringizni ishlashingiz mumkin!*";
        } else {
            $message = "*Botda pul ishlash uchun kanllarga qo'shiling va A'zo bo'ldim tugmani bosing!*";
        }
        $kanallar = $db->queryRows('SELECT * FROM channels ');
        $kanal_arr = [];
        foreach ($kanallar as $kan) {
            $obuna = json_decode($kanal->cha($client, $kan['channel'], $chat_id))->result->status;
            if ($obuna == "left") {//kanalda bor bo'lsa chiqmasin
                $canal = "⚠️ Qo'shilish " . $kan['name'];
                $kanal_arr[] = [['text' => $canal, 'url' => $kan['link']]];
            }
        }
        $kanal_arr[] = [['text' => "♻️ A'zo bo'ldim", 'callback_data' => "tayyor"]];
        $inline_key = json_encode(['inline_keyboard' => $kanal_arr]);

        $bot->rg('sendmessage', $chat_id, $message, $inline_key);

        $refi = str_replace($chat_id, '', explode("/start ", $text)[1]);
        $user_on_k = $db->queryValue('SELECT COUNT (*) FROM users WHERE cid = "' . $chat_id . '" ');

        if ($user_on_k == 0) {
            $db->exec('INSERT INTO "users" ("cid", "referal", "hisob")
    VALUES ("' . $chat_id . '", "' . $refi . '", "0")');
        }

    }

}

if ($cdata == "success") {
    $bot->go('editMessageReplyMarkup', ['chat_id' => $adm, 'message_id' => $cmid, 'inline_message_id' => $callid, 'reply_markup' => json_encode(['inline_keyboard' => [[['text' => "✅ To'langan", 'callback_data' => "x"]]]])]);
    $user = explode('ID: ', $callback['message']['text'])[1];
    $bot->rg('sendmessage', $user, "*Pullaringiz hisobingizga to'landi*\n_Yana do'stlar taklif qilishni davom eting omad!_");
}

require('admin.php');

/**
 * Yakunlandi: 26.05.2020 / 19:36
 * Avtor: Morgan
 * Telegram: @C_Morgan
 * Taqiqlanadi: Sotish, Tarqatish
 **/
?>