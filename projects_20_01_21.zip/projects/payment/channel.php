<?php

use GuzzleHttp\Client;
require 'vendor/autoload.php';

$client = new Client();

class Channel {
	
	public function cha($client, $chs, $user)	{
	$token = "1120423625:AAFZi-pkXOwDKCjrT4Ys2e8Z4asSq2D2JHc";
	
	$response = $client->request('GET', 'https://api.telegram.org/bot'.$token.'/getchatmember?chat_id='.$chs.'&user_id='.$user);

	//echo $response->getStatusCode(),"<br>";
	$body = $response->getBody();
	return $body->getContents();
}
public function tekshir($client, $chat) {
	$ch = explode('#', file_get_contents('kanallar.txt'));	
$c = '';
	for($i=1; $i<count($ch); $i++) {
	$c .= json_decode($this->cha($client, $ch[$i], $chat))->result->status." ";
	}
	return $c;
	}
	
	}
	
	

/**	
	echo "<pre>";
	print_r(get_class_methods($body));
	echo "</pre>";
	echo "<pre>";
	print_r(get_class_methods($response));
	echo "</pre>";
**/

?>