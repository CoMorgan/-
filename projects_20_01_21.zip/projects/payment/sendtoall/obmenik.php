<?php
date_default_timezone_set('Asia/Tashkent');
require_once('info.php');
include 'sqlite/lib/sqlite.php';
$db = new Db('malumot.sqlite');

require_once('kurslar.php');



$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$cid = $message->chat->id;
$tex = $message->text;
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

if ($message) { $kid = $cid; } else { $kid = $update->callback_query->message->chat->id; }
$em = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$kid.'" ');
define('ID',$em['user_id']);
define('FIO',$em['fio']);


function rg($met, $sid, $matn, $markup = false, $md = false) {

return bot($met, [
        'chat_id' => $sid,
'message_id'=>$md,
        'text' => $matn,
        'parse_mode'=>"markdown",
'reply_markup'=>$markup,
'disable_web_page_preview'=>true
    ]); 
}

 
function ACL($callbackQueryId, $text = null, $showAlert = false)
{
     return bot('answerCallbackQuery', [
        'callback_query_id' => $callbackQueryId,
        'text' => $text,
        'show_alert'=>$showAlert,
    ]);
}
function get($fayl){
$get = file_get_contents("$fayl");
return $get;
}

$menu_ru = json_encode(['one_time_keyboard'=>true, 'resize_keyboard'=>true,
'keyboard'=>[[['text'=>"🔄Обмен"]],[['text'=>"🔰Кошельки"],['text'=>"📊Курс и 💰Резервы"]],[['text'=>"📂История заявок"],['text'=>"📓О нас"]],[['text'=>"👥Рефералы"],['text'=>"📞Тех.поддержка"]]]]);
$menu_uz = json_encode(['one_time_keyboard'=>true, 'resize_keyboard'=>true,
'keyboard'=>[[['text'=>"🔄Valyuta ayirboshlash"]],[['text'=>"🔰Hamyonlar"],['text'=>"📊Kurs va 💰Zahira"]],[['text'=>"📂Almashuvlar"],['text'=>"📓Biz haqimizda"]],[['text'=>"👥Referallar"],['text'=>"📞Aloqa"]]]]);

//#
$admin = ['587144350','266873587','652903849'];
$adm = "652903849";//Glavniy

if ($update->callback_query) $id = $update->callback_query->message->chat->id; else $id = $message->chat->id;
$tili = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$id.'" ');
$tyl = $tili['lang'];

define('TIL',$tyl);
function til($tl) {
$ln = file_get_contents("lang_".TIL.".lng");
preg_match_all('|'.$tl.'="(.*)"|Uis', $ln, $ex);
return $ex[1][0];
}
$menu = json_encode(['one_time_keyboard'=>true, 'resize_keyboard'=>true,
'keyboard'=>[[['text'=>til(obmen)]],[['text'=>til(danniy)],['text'=>til(kurs)]],[['text'=>til(istoriya)],['text'=>til(biz)]],[['text'=>til(ref)],['text'=>til(aloqa)]]]]);
///CALLBACK QISM


  $call=$update->callback_query;
$dat=$call->data;
$mid = $call->message->message_id;
$chid = $call->message->chat->id;



if($tex == "/start") {
rg('sendmessage', $cid, "Выберите язык интерфейса💬\n\nInterfeys tilini tanlang", json_encode(['inline_keyboard'=>[[['text'=>"Русский", 'callback_data'=>"ru"],['text'=>"O'zbek tili", 'callback_data'=>"uz"]]]]));
$count = $db->queryValue('SELECT COUNT (*) FROM users WHERE user_id = "'.$cid.'" ');
if ($count == 0) {
$db->exec('INSERT INTO "users" ("user_id")
    VALUES ("'.$cid.'")');
}
}

if ($dat == "uz") {

$db->update('users', array('lang' => 'uz', 'geo' => 'start'), 'user_id=:id', array(':id' => $chid)); 
rg('deleteMessage', $chid, true, true, $mid);
rg('sendmessage', $chid, "*".$company."* - bu O'zbekiston hududidagi *ishonchli valyuta almashuv servisi.*\n\nBizning *Sayt:* ".$site, $menu_uz);
}
if ($dat == "ru") {
$db->update('users', array('lang' => 'ru', 'geo'=> 'start'), 'user_id=:id', array(':id' => $chid)); 

rg('deleteMessage', $chid, true, true, $mid);
rg('sendmessage', $chid, "*".$company."* - это *надежный сервис обмена валют на территории Узбекистана.*\n\nНаш *Сайт:* ".$site, $menu_ru);

}


$otdat  =json_encode(['inline_keyboard'=>[[['text'=>"⏫ UZCARD", 'callback_data'=>"uzcardb"],['text'=>"⏬  UZCARD", 'callback_data'=>"uzcardo"]],[['text'=>"⏫ HUMO UZS", 'callback_data'=>"humob"],['text'=>"⏬ HUMO UZS", 'callback_data'=>"humoo"]],[['text'=>"⏫ WMR", 'callback_data'=>"wmrb"],['text'=>"⏬ WMR", 'callback_data'=>"wmro"]],[['text'=>"⏫ WMZ", 'callback_data'=>"wmzb"],['text'=>"⏬ WMZ", 'callback_data'=>"wmzo"]],[['text'=>"⏫ Yandex RUB", 'callback_data'=>"yandexb"],['text'=>"⏬ Yandex RUB", 'callback_data'=>"yandexo"]],[['text'=>"⏫ QIWI RUB", 'callback_data'=>"qiwib"],['text'=>"⏬ QIWI RUB", 'callback_data'=>"qiwio"]],[['text'=>"⏫ PAYEER RUB", 'callback_data'=>"payerrubb"],['text'=>"⏬ PAYEER RUB", 'callback_data'=>"payerrubo"]],[['text'=>"⏫ PAYEER USD", 'callback_data'=>"payerusdb"],['text'=>"⏬ PAYEER USD", 'callback_data'=>"payerusdo"]],[['text'=>"⏫ Beeline MB", 'callback_data'=>"megab"],['text'=>"⏬ Beeline MB", 'callback_data'=>"megao"]],[['text'=>"⏫ Сбербанк RUB", 'callback_data'=>"sberb"],['text'=>"⏬ Сбербанк RUB", 'callback_data'=>"sbero"]],[['text'=>"▫️", 'callback_data'=>"xbetusdb"],['text'=>"⏬ 1XBET UZS", 'callback_data'=>"xbetuzso"]],[['text'=>"▫️", 'callback_data'=>"xbetusdb"],['text'=>"⏬ 1XBET RUB", 'callback_data'=>"xbetrubo"]],[['text'=>"▫️", 'callback_data'=>"xbetusdb"],['text'=>"⏬ 1XBET USD", 'callback_data'=>"xbetusdo"]],]]);
	
if (!empty($em['fio'])) {//FiSh

if ($em['ban'] == "0") {//BANLANDI

if ($tex == til(obmen)) {
if (get('off.morgan') == "0") {//STOP
$obe = $db->queryValue('SELECT COUNT (*) FROM obmen WHERE cid = "'.$cid.'" AND sts = "tekshiruv" ');
if($obe == 0) {
$tili = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$cid.'" ');
rg('sendmessage', $cid, til(obmenit), $otdat);
$db->exec("UPDATE obmen SET otype='', btype='' WHERE cid='".$cid."' AND sts = 'loading' ");
$db->exec("UPDATE users SET geo='' WHERE user_id='".$cid."' ");
} else {

$kx = til(kuting);
rg('sendmessage', $cid, $kx, json_encode(['inline_keyboard'=>[[['text'=>til(holatimiz), 'callback_data'=>"holat"]]]]));}

} else {//STOP
rg('sendmessage', $cid, "*".get('off.morgan')."*");
}
}
}//BAN
if ($dat == "holat") {
$dan = $db->queryRow('SELECT * FROM obmen WHERE cid = "'.$chid.'" ORDER BY time DESC');
$sts = str_replace('tekshiruv', til(prover), $dan['sts']);
$sts = str_replace('success', til(tulandi), $sts);
$sts = str_replace('otmen', til(otmen), $sts);
$ho = "ID: ".$dan['id']."\n".til(berish)." ".$dan['berish']." ".$dan['btype']."\n".til(olish)." ".$dan['olish']." ".$dan['otype']."\n".til(sts)." ".$sts."\n".til(time)." ".date('d.m.y / H:i:s', $dan['time']);
bot('answerCallbackQuery',
 ['callback_query_id'=>$call->id, 'text' => $ho, 'show_alert'=>true]);
}


if (in_array($cid, $admin)) {
if(mb_stripos($tex,"#sotish") !== false || mb_stripos($tex,"#olish") !== false){
$xe = explode('#', $tex);
$xi = "*".$xe[1]."*\n\nℹ Turi: ".$xe[2]."\n↗ Kurs: ".$xe[3];
rg('sendmessage', $cid, $xi);
$coun = $db->queryValue('SELECT COUNT (*) FROM valyut WHERE turi = "'.$xe[2].'" ');
if ($coun == 0) {
$db->exec('INSERT INTO "valyut" ("'.$xe[1].'", "turi")
    VALUES ("'.$xe[3].'", "'.$xe[2].'")'); } else {
$db->exec("UPDATE valyut SET $xe[1]='".$xe[3]."' WHERE turi='".$xe[2]."' ");
}
}
}


include 'almashuv.php';//OBMEN

$otziv = json_encode(['inline_keyboard'=>[[['text'=>til(otziv), 'url'=>"t.me/myobmenchek"]]]]);
if($dat == "succes") {
preg_match_all('|~(.*)~|Uis', json_encode($call->message->text), $bu);
preg_match_all('|"first_name":"(.*)",|Uis', json_encode($call->message->entities), $nik);
$ka = $db->queryRow('SELECT * FROM obmen WHERE cid = "'.$bu[1][0].'" AND sts = "tekshiruv" ');
$use = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$bu[1][0].'" ');
if ($ka['otype'] == "QIWI RUB") { $p1 = "✅"; } else if($ka['otype'] == "UZCARD") { $p2 = "✅"; } else if($ka['otype'] == "WMR") { $p3 = "✅"; } else if($ka['otype'] == "WMZ") { $p4 = "✅"; } else if($ka['otype'] == "1XBET RUB") { if($db->queryValue('SELECT COUNT (*) FROM belgi WHERE xid = "'.$use['xbetrub'].'" ') == 1) { $zn = "🔝"; } $p5 = "✅ ".$zn; } else if($ka['otype'] == "Beeline MB") { $p6 = "✅"; } else if($ka['otype'] == "Sberbank") { $p7 = "✅"; } else if($ka['otype'] == "YANDEX RUB") { $p8 = "✅"; } else if($ka['otype'] == "1XBET USD") { if($db->queryValue('SELECT COUNT (*) FROM belgi WHERE xid = "'.$use['xbetusd'].'" ') == 1) { $zn = "🔝"; } $p9 = "✅ ".$zn; } else if($ka['otype'] == "HUMO UZS") { $p10 = "✅"; } else if($ka['otype'] == "1XBET UZS") { if($db->queryValue('SELECT COUNT (*) FROM belgi WHERE xid = "'.$use['xbetuzs'].'" ') == 1) { $zn = "🔝"; } $p11 = "✅ ".$zn; } else if($ka['otype'] == "QIWI RUB ru") { $p12 = "✅";  } else if($ka['otype'] == "PAYEER RUB" || $ka['otype'] == "PAYEER USD") { $p13 = "✅";  }
$xabar = "*- Yangi almashuv: (".$ka['id'].")*\n\n*◽️Ismi: *".$use['fio']."\n◽️*Raqami: *".$use['nomer']."\n\n*↗️O'tkazdi: *".$ka['berish']." ".$ka['btype']."\n*↙️Olmoqchi: *".$ka['olish']." ".$ka['otype']."\n*⏰Vaqti:* ".date('d.m.y / H:i:s', $ka['time'])."\n\n*🇷🇺QIWI UZ: *`".$use['qiwi']."` ".$p1."\n\n*🇷🇺QIWI RU: *`".$use['qiwiru']."` ".$p12."\n\n*🇺🇿UZCARD:* `".$use['uzcard']."` ".$p2."\n\n*🇺🇿 HUMO:* `".$use['humo']."` ".$p10."\n\n🇷🇺*YANDEX: *`".$use['yandex']."` ".$p8."\n\n*🇷🇺WMZ: *`".$use['wmz']."` ".$p4."\n\n*🇷🇺WMR:* `".$use['wmr']."` ".$p3."\n\n🇷🇺*1XBET RUB: *`".$use['xbetrub']."` ".$p5."\n\n🇷🇺*1XBET USD: *`".$use['xbetusd']."` ".$p9."\n\n🇺🇿*1XBET UZS: *`".$use['xbetuzs']."` ".$p11."\n\n*🔋BEELINE: *`".$use['beeline']."` ".$p6."\n\n🇷🇺*Сбербанк: *`".$use['sberbank']."` ".$p7."\n\n🇷🇺*PAYEER: *`".$use['payeer']."` ".$p13."\n\n*📱TELEGRAM: *[-".$use['fio']."-](tg://user?id=".$use['user_id'].")\n\n✅*TO'LANDI*";
rg('editMessageText', $chid, $xabar, $not, $mid);
rg('sendmessage', $bu[1][0], "✅* ".$ka['olish']." ".$ka['otype']." Hisobingizga tushirildi 🇺🇿\n\n✅ ".$ka['olish']." ".$ka['otype']." Был зачислен на ваш счет 🇷🇺*", $otziv);
$db->exec("UPDATE obmen SET sts='success' WHERE cid='".$bu[1][0]."' AND sts = 'tekshiruv' ");

///####REZERV ZAHIRANI TAXRIRLASH#####
if ($ka['btype'] == "QIWI RUB") {
$miq = $ka['berish']; $qiwi = get('byudjet/qiwi.rg'); $plus = $qiwi + $miq; file_put_contents('byudjet/qiwi.rg', $plus); }
if($ka['otype'] == "UZCARD") {
$miq = $ka['olish']; $uzc = get('byudjet/uzcard.rg'); $pro = $miq * 1 / 100; $oba = $miq + $pro; $minus = $uzc - $oba; file_put_contents('byudjet/uzcard.rg', $minus); }
if($ka['otype'] == "HUMO UZS") {
$miq = $ka['olish']; $uzc = get('byudjet/humo.rg'); $pro = $miq * 1 / 100; $oba = $miq + $pro; $minus = $uzc - $oba; file_put_contents('byudjet/humo.rg', $minus); }
if ($ka['btype'] == "YANDEX RUB") {
$miq = $ka['berish']; $yande = get('byudjet/yandex.rg'); $plus = $yande + $miq; file_put_contents('byudjet/yandex.rg', $plus); }
if($ka['otype'] == "QIWI RUB") {
$miq = $ka['olish']; $qiw = get('byudjet/qiwi.rg'); $minus = $qiw - $miq; file_put_contents('byudjet/qiwi.rg', $minus); }
if($ka['otype'] == "1XBET RUB") {
$miq = $ka['olish']; $qiw = get('byudjet/xbetrub.rg'); $minus = $qiw - $miq; file_put_contents('byudjet/xbetrub.rg', $minus); }
if ($ka['btype'] == "UZCARD") {
$miq = $ka['berish']; $uzca = get('byudjet/uzcard.rg'); $plus = $uzca + $miq; file_put_contents('byudjet/uzcard.rg', $plus); }

if($ka['otype'] == "YANDEX RUB") {
$miq = $ka['olish']; $yand = get('byudjet/yandex.rg'); 
 $minus = $yand - $miq; file_put_contents('byudjet/yandex.rg', $minus); } 
if ($ka['btype'] == "QIWI RUB ru") {
$miq = $ka['berish']; $qiwi = get('byudjet/qiwiru.rg'); $plus = $qiwi + $miq; file_put_contents('byudjet/qiwiru.rg', $plus); }
if ($ka['btype'] == "HUMO UZS") {
$miq = $ka['berish']; $uzca = get('byudjet/humo.rg'); $plus = $uzca + $miq; file_put_contents('byudjet/humo.rg', $plus); }
if($ka['otype'] == "QIWI RUB ru") {
$miq = $ka['olish']; $qiw = get('byudjet/qiwiru.rg'); $minus = $qiw - $miq; file_put_contents('byudjet/qiwiru.rg', $minus); }


if ($ka['btype'] == "WMR") {
$miq = $ka['berish']; $wmr = get('byudjet/wmr.rg'); $plus = $wmr + $miq; file_put_contents('byudjet/wmr.rg', $plus); }
if ($ka['otype'] == "WMR") {
$miq = $ka['olish']; $wmr = get('byudjet/wmr.rg'); $plus = $wmr - $miq; file_put_contents('byudjet/wmr.rg', $plus); }
if ($ka['btype'] == "PAYEER RUB") {
$miq = $ka['berish']; $payerrub = get('byudjet/payerrub.rg'); $plus = $payerrub + $miq; file_put_contents('byudjet/payerrub.rg', $plus); }
if ($ka['otype'] == "PAYEER RUB") {
$miq = $ka['olish']; $payerrub = get('byudjet/payerrub.rg'); $plus = $payerrub - $miq; file_put_contents('byudjet/payerrub.rg', $plus); }
if ($ka['btype'] == "PAYEER USD") {
$miq = $ka['berish']; $payerusd = get('byudjet/payerusd.rg'); $plus = $payerusd + $miq; file_put_contents('byudjet/payerusd.rg', $plus); }
if ($ka['otype'] == "PAYEER USD") {
$miq = $ka['olish']; $payerusd = get('byudjet/payerusd.rg'); $plus = $payerusd - $miq; file_put_contents('byudjet/payerusd.rg', $plus); }
if ($ka['btype'] == "WMZ") {
$miq = $ka['berish']; $wmz = get('byudjet/wmz.rg'); $plus = $wmz + $miq; file_put_contents('byudjet/wmz.rg', $plus); }
if ($ka['otype'] == "WMZ") {
$miq = $ka['olish']; $wmz = get('byudjet/wmz.rg'); $plus = $wmz - $miq; file_put_contents('byudjet/wmz.rg', $plus); }
if ($ka['otype'] == "1XBET USD") {
$miq = $ka['olish']; $wmz = get('byudjet/xbetusd.rg'); $plus = $wmz - $miq; file_put_contents('byudjet/xbetusd.rg', $plus); }
if ($ka['btype'] == "Sberbank") {
$miq = $ka['berish']; $sb = get('byudjet/sberbank.rg'); $plus = $sb + $miq; file_put_contents('byudjet/sberbank.rg', $plus); }
if ($ka['otype'] == "Sberbank") {
$miq = $ka['olish']; $sb = get('byudjet/sberbank.rg'); $plus = $sb - $miq; file_put_contents('byudjet/sberbank.rg', $plus); }
if ($ka['btype'] == "Beeline MB") {
$miq = $ka['berish']; $bee = get('byudjet/beeline.rg'); $plus = $bee + $miq; file_put_contents('byudjet/beeline.rg', $plus); }
if ($ka['otype'] == "Beeline MB") {
$miq = $ka['olish']; $bee = get('byudjet/beeline.rg'); $plus = $bee - $miq; file_put_contents('byudjet/beeline.rg', $plus); }
if($ka['otype'] == "1XBET UZS") {
$miq = $ka['olish']; $qiw = get('byudjet/xbetuzs.rg'); $minus = $qiw - $miq; file_put_contents('byudjet/xbetuzs.rg', $minus); }
//REFERALGA PLUS
$olsh = $ka['otype'];
$ber= $ka['btype'];
$b = $ka['berish'];
$o = $ka['olish'];
$fid =$ka['cid'];
$r = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$fid.'" ');
if($ber == "UZCARD" || $ber == "HUMO UZS") {
$w = str_replace('WMR', $wm, $olsh);
$w = str_replace('QIWI RUB ru', $qiwiruo, $w);
$w = str_replace('YANDEX RUB', $ya, $w);
$w = str_replace('1XBET RUB', $xbetrubo, $w);
$w = str_replace('WMZ', $wmzo, $w);
$w = str_replace('1XBET USD', $xbetusdo, $w);
$w = str_replace('QIWI RUB', $qi, $w);
$w = str_replace('Sberbank', $sbo, $w);
$w = str_replace('PAYEER RUB', $payerrubo, $w);
$w = str_replace('PAYEER USD', $payerusdo, $w);

$f = $o * $w;
$a = $b - $f;
$g = $a * 10 / 100;
$db->exec("UPDATE users SET hisob = hisob + '".$g."'  WHERE user_id='".$r['ref']."' ");

}

///ISBOT KANAL
$ism = bot('getchat', ['chat_id'=>$ka['cid']])->result->first_name;
$isbot = "Обмен через бота @Myobmenuzbot\nID: ".$ka['id']."
👤: ".$ism."
🔀: ".$ka['btype']." ⏩ ".$ka['otype']."
📆: ".date('d.m.y H:i', $ka['time'])."
🔎Статус: ✅
💰: ".$ka['olish']." ".$ka['otype'];
rg('sendmessage', $isbotk, $isbot);
}
if ($dat == "neplachen") {
preg_match_all('|~(.*)~|Uis', json_encode($call->message->text), $bu);
$ka = $db->queryRow('SELECT * FROM obmen WHERE cid = "'.$bu[1][0].'" AND sts = "tekshiruv" ');
$use = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$bu[1][0].'" ');
if ($ka['otype'] == "QIWI RUB") { $p1 = "❌"; } else if($ka['otype'] == "UZCARD") { $p2 = "❌"; } else if($ka['otype'] == "WMR") { $p3 = "❌"; } else if($ka['otype'] == "WMZ") { $p4 = "❌"; } else if($ka['otype'] == "1XBET RUB") { if($db->queryValue('SELECT COUNT (*) FROM belgi WHERE xid = "'.$use['xbetrub'].'" ') == 1) { $zn = "🔝"; } $p5 = "❌ ".$zn; } else if($ka['otype'] == "Beeline MB") { $p6 = "❌"; } else if($ka['otype'] == "Sberbank") { $p7 = "❌"; } else if($ka['otype'] == "YANDEX RUB") { $p8 = "❌"; } else if($ka['otype'] == "1XBET USD") { if($db->queryValue('SELECT COUNT (*) FROM belgi WHERE xid = "'.$use['xbetusd'].'" ') == 1) { $zn = "🔝"; } $p9 = "❌ ".$zn; } else if($ka['otype'] == "HUMO UZS") { $p10 = "❌"; } else if($ka['otype'] == "1XBET UZS") { if($db->queryValue('SELECT COUNT (*) FROM belgi WHERE xid = "'.$use['xbetuzs'].'" ') == 1) { $zn = "🔝"; } $p11 = "❌ ".$zn; } else if($ka['otype'] == "QIWI RUB ru") { $p12 = "❌"; } else if($ka['otype'] == "PAYEER RUB" || $ka['otype'] == "PAYEER USD") { $p13 = "❌"; }
$xabar = "*- Yangi almashuv: (".$ka['id'].")*\n\n*◽️Ismi: *".$use['fio']."\n◽️*Raqami: *".$use['nomer']."\n\n*↗️O'tkazdi: *".$ka['berish']." ".$ka['btype']."\n*↙️Olmoqchi: *".$ka['olish']." ".$ka['otype']."\n*⏰Vaqti:* ".date('d.m.y / H:i:s', $ka['time'])."\n\n*🇷🇺QIWI UZ: *`".$use['qiwi']."` ".$p1."\n\n*🇷🇺QIWI RU: *`".$use['qiwiru']."` ".$p12."\n\n*🇺🇿UZCARD:* `".$use['uzcard']."` ".$p2."\n\n*🇺🇿 HUMO:* `".$use['humo']."` ".$p10."\n\n🇷🇺*YANDEX: *`".$use['yandex']."` ".$p8."\n\n*🇷🇺WMZ: *`".$use['wmz']."` ".$p4."\n\n*🇷🇺WMR:* `".$use['wmr']."` ".$p3."\n\n🇷🇺*1XBET RUB: *`".$use['xbetrub']."` ".$p5."\n\n🇷🇺*1XBET USD: *`".$use['xbetusd']."` ".$p9."\n\n🇺🇿*1XBET UZS: *`".$use['xbetuzs']."` ".$p11."\n\n*🔋BEELINE: *`".$use['beeline']."` ".$p6."\n\n🇷🇺*Сбербанк: *`".$use['sberbank']."` ".$p7."\n\n🇷🇺*PAYEER: *`".$use['payeer']."` ".$p13."\n\n*📱TELEGRAM: *[-".$use['fio']."-](tg://user?id=".$use['user_id'].")\n\n❌*BEKOR QILINDI*";
rg('editMessageText', $chid, $xabar, $not, $mid);
preg_match_all('|~(.*)~|Uis', json_encode($call->message->text), $bu);
rg('sendmessage', $bu[1][0], "❌* ".$ka['olish']." ".$ka['otype']." Siz pulni tashlamadingiz 🇺🇿\n\n❌ ".$ka['olish']." ".$ka['otype']." Вы не бросали деньги 🇷🇺*", $otziv);
$db->exec("UPDATE obmen SET sts='otmen' WHERE cid='".$bu[1][0]."' AND sts = 'tekshiruv' ");
}
if($dat == "ban") {
preg_match_all('|~(.*)~|Uis', json_encode($call->message->text), $bu);
$ism = bot('getchat', ['chat_id'=>$bu[1][0]])->result->first_name;
$xabar = "[".$ism."](tg://user?id=".$bu[1][0].") - 🚫 BANLANDI";
rg('editMessageText', $chid, $xabar, $not, $mid);
$db->exec("UPDATE obmen SET sts='otmen' WHERE cid='".$bu[1][0]."' AND sts = 'tekshiruv' ");
$db->exec("UPDATE users SET ban='1' WHERE user_id='".$bu[1][0]."' ");
}


if ($dat == "otmen") {
$db->exec("DELETE FROM obmen WHERE cid='".$chid."' AND sts = 'loading' ");
rg('deleteMessage', $chid, true, true, $mid);
rg('sendmessage', $chid, "*".til(bekor)."*", $menu);
}

//##########################BAZAGA HISOB KIRITISH###########################

$cash = json_encode(['one_time_keyboard'=>true, 'resize_keyboard'=>true,
'keyboard'=>[[['text'=>"➕YANDEX"],['text'=>"➕QIWI RUB"],['text'=>"➕PAYEER"]],[['text'=>"➕UZCARD"],['text'=>"➕WMR"],['text'=>"➕WMZ"]],[['text'=>"➕Сбербанк"],['text'=>"➕Beeline"],['text'=>"➕HUMO"]],[['text'=>"➕1XBET RUB"],['text'=>"➕1XBET USD"],['text'=>"➕1XBET UZS"]],[['text'=>til(menu)]]]]);
$caw = json_encode(['inline_keyboard'=>[[['text'=>til(chistit), 'callback_data'=>"clear"]]]]);
$danniy = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$cid.'" ');
if (!empty($danniy['yandex'])) {
$yandex = $danniy['yandex']; } else { $yandex = til(pusto); }
if (!empty($danniy['qiwi'])) {
$qiwi = $danniy['qiwi']; } else { $qiwi = til(pusto); }
if (!empty($danniy['qiwiru'])) {
$qiwiru = $danniy['qiwiru']; } else { $qiwiru = til(pusto); }
if (!empty($danniy['uzcard'])) {
$uzcard = $danniy['uzcard']; } else { $uzcard = til(pusto); }
if (!empty($danniy['wmr'])) {
$wmr = $danniy['wmr']; } else { $wmr = til(pusto); }
if (!empty($danniy['xbetrub'])) {
$xbr = $danniy['xbetrub']; } else { $xbr = til(pusto); }
if (!empty($danniy['wmz'])) {
$wmz = $danniy['wmz']; } else { $wmz = til(pusto); }
if (!empty($danniy['sberbank'])) {
$sber = $danniy['sberbank']; } else { $sber = til(pusto); }
if (!empty($danniy['beeline'])) {
$bel = $danniy['beeline']; } else { $bel= til(pusto); } 
if (!empty($danniy['xbetusd'])) {
$xbst = $danniy['xbetusd']; } else { $xbst= til(pusto); }
if (!empty($danniy['humo'])) {
$humo = $danniy['humo']; } else { $humo= til(pusto); }
if (!empty($danniy['xbetuzs'])) {
$xbz = $danniy['xbetuzs']; } else { $xbz= til(pusto); }
if (!empty($danniy['payeer'])) {
$pay = $danniy['payeer']; } else { $xbs= til(pusto); }
$kash = "📌*QIWI:*
`".$qiwi."`
📌*YANDEX:*
`".$yandex."`
📌*UZCARD:*
`".$uzcard."`
📌*HUMO:*
`".$humo."`
📌*WMR:*
`".$wmr."`
📌*1XBET RUB:*
`".$xbr."`
📌*1XBET USD:*
`".$xbst."`
📌*1XBET UZS:*
`".$xbz."`
📌*WMZ:*
`".$wmz."`
📌*Сбербанк:*
`".$sber."`
📌*BEELINE:*
`".$bel."`
📌*PAYEER:*
`".$pay."`";
if ($tex == til(danniy)) {
rg('sendmessage', $cid, til(kashelok), $cash);
rg('sendmessage', $cid, $kash, $caw);
$db->exec("UPDATE users SET geo='dannie' WHERE user_id='".$cid."' ");
//$db->exec("UPDATE obmen SET otype='', btype='' WHERE cid='".$cid."' AND sts = 'loading' ");
}
if ($tex == "➕QIWI RUB" || $tex == "➕YANDEX" || $tex == "➕UZCARD" || $tex == "➕WMR" || $tex == "➕Beeline" || $tex == "➕WMZ" || $tex == "➕Сбербанк" || $tex == "➕1XBET RUB" || $tex == "➕1XBET USD" || $tex == "➕HUMO" || $tex == "➕1XBET UZS" || $tex == "➕PAYEER") {
$kashe = str_replace('➕QIWI RUB', til(schet_q), $tex);
//$kashe = str_replace('➕QIWI RU', til(schet_qr), $kashe);
$kashe = str_replace('➕YANDEX', til(schet_y), $kashe);
$kashe = str_replace('➕UZCARD', til(schet_c), $kashe);
$kashe = str_replace('➕WMR', til(schet_w), $kashe);
$kashe = str_replace('➕WMZ', til(schet_wz), $kashe);
$kashe = str_replace('➕Сбербанк', til(schet_sb), $kashe);
$kashe = str_replace('➕1XBET RUB', til(schet_xbr), $kashe);
$kashe = str_replace('➕1XBET USD', til(schet_xbs), $kashe);
$kashe = str_replace('➕1XBET UZS', til(schet_xbz), $kashe);
$kashe = str_replace('➕Beeline', til(schet_b), $kashe);
$kashe = str_replace('➕HUMO', til(schet_pay), $kashe);
$kashe = str_replace('➕PAYEER', til(schet_payer), $kashe);
$db->exec("UPDATE users SET geo='".$tex."' WHERE user_id='".$cid."' ");

if ($tex == "➕1XBET UZS" || $tex == "➕1XBET RUB" || $tex == "➕1XBET USD") { 
	rg('sendmessage', $cid, til(promo));
	}
rg('sendmessage', $cid, $kashe);
}
$d = $db->queryRow('SELECT * FROM users WHERE user_id = "'.$cid.'" ');
if($d['geo'] == "➕QIWI RUB") {
if(mb_stripos($tex,"+99") !== false || mb_stripos($tex,"+7") !== false){
$no = substr($tex, 0, 13);
$d['geo'] = str_replace('➕', '', $d['geo']);
$j = str_replace('{kash}', $d['geo'], til(uspeshno));
rg('sendmessage', $cid, $j);
$db->exec("UPDATE users SET qiwi='".$no."', geo='#' WHERE user_id='".$cid."' ");
}}
/*
if($d['geo'] == "➕QIWI RU") {
if(mb_stripos($tex,"+7") !== false){
$no = substr($tex, 0, 13);
$d['geo'] = str_replace('➕', '', $d['geo']);
$j = str_replace('{kash}', $d['geo'], til(uspeshno));
rg('sendmessage', $cid, $j);
$db->exec("UPDATE users SET qiwiru='".$no."', geo='#' WHERE user_id='".$cid."' ");
}}*/
if($d['geo'] == "➕UZCARD") {
if(mb_stripos($tex,"8600") !== false || stripos($tex,"6262") !== false){
$tex = str_replace(' ', '', $tex);
if (strlen($tex) > 15){
$no = substr($tex, 0, 16);
$d['geo'] = str_replace('➕', '', $d['geo']);
$j = str_replace('{kash}', $d['geo'], til(uspeshno));

rg('sendmessage', $cid, $j);
$db->exec("UPDATE users SET uzcard='".$no."', geo='#' WHERE user_id='".$cid."' ");
}}}


if($d['geo'] == "➕YANDEX") {

if (preg_match('/[0-9]/i', $tex)){
if (strlen($tex) > 12){
$no = is_int($tex);
$d['geo'] = str_replace('➕', '', $d['geo']);
$j = str_replace('{kash}', $d['geo'], til(uspeshno));

rg('sendmessage', $cid, $j);
$db->exec("UPDATE users SET yandex='".$tex."', geo='#' WHERE user_id='".$cid."' ");
}}}
if($d['geo'] == "➕WMR") {
if (preg_match('/R/i', $tex)){
if (preg_match('/[0-9]/i', $tex)){

if (strlen($tex) > 12){

$d['geo'] = str_replace('➕', '', $d['geo']);
$j = str_replace('{kash}', $d['geo'], til(uspeshno));

rg('sendmessage', $cid, $j);
$db->exec("UPDATE users SET wmr='".$tex."', geo='#' WHERE user_id='".$cid."' ");
}}}}
if($d['geo'] == "➕PAYEER") {
if (preg_match('/P/i', $tex)){
if (preg_match('/[0-9]/i', $tex)){



$d['geo'] = str_replace('➕', '', $d['geo']);
$j = str_replace('{kash}', $d['geo'], til(uspeshno));

rg('sendmessage', $cid, $j);
$db->exec("UPDATE users SET payeer='".$tex."', geo='#' WHERE user_id='".$cid."' ");
}}}
if($d['geo'] == "➕WMZ") {
if (preg_match('/Z/i', $tex)){
if (preg_match('/[0-9]/i', $tex)){
if (strlen($tex) > 12){

$d['geo'] = str_replace('➕', '', $d['geo']);
$j = str_replace('{kash}', $d['geo'], til(uspeshno));

rg('sendmessage', $cid, $j);
$db->exec("UPDATE users SET wmz='".$tex."', geo='#' WHERE user_id='".$cid."' ");
}}}}
if($d['geo'] == "➕1XBET RUB") {
if (preg_match('/1|2|3|4|5|6|7|8|9|0/i', $tex)){
if (strlen($tex) < 11){

$d['geo'] = str_replace('➕', '', $d['geo']);
$j = str_replace('{kash}', $d['geo'], til(uspeshno));

rg('sendmessage', $cid, $j);
$db->exec("UPDATE users SET xbetrub='".$tex."', geo='#' WHERE user_id='".$cid."' ");
}}}

if($d['geo'] == "➕1XBET UZS") {
if (preg_match('/1|2|3|4|5|6|7|8|9|0/i', $tex)){
if (strlen($tex) < 11){

$d['geo'] = str_replace('➕', '', $d['geo']);
$j = str_replace('{kash}', $d['geo'], til(uspeshno));

rg('sendmessage', $cid, $j);
$db->exec("UPDATE users SET xbetuzs='".$tex."', geo='#' WHERE user_id='".$cid."' ");
}}}
if($d['geo'] == "➕1XBET USD") {
if (preg_match('/1|2|3|4|5|6|7|8|9|0/i', $tex)){
if (strlen($tex) < 11){

$d['geo'] = str_replace('➕', '', $d['geo']);
$j = str_replace('{kash}', $d['geo'], til(uspeshno));

rg('sendmessage', $cid, $j);
$db->exec("UPDATE users SET xbetusd='".$tex."', geo='#' WHERE user_id='".$cid."' ");
}}}
if($d['geo'] == "➕Сбербанк") {
if (preg_match('/1|2|3|4|5|6|7|8|9|0/i', $tex)){
$tex = str_replace(' ', '', $tex);
if (strlen($tex) > 15){

$d['geo'] = str_replace('➕', '', $d['geo']);
$j = str_replace('{kash}', $d['geo'], til(uspeshno));

rg('sendmessage', $cid, $j);
$db->exec("UPDATE users SET sberbank='".$tex."', geo='#' WHERE user_id='".$cid."' ");
}}}
if($d['geo'] == "➕Beeline") {
if(stripos($tex,"90") !== false || stripos($tex,"91") !== false){
if (strlen($tex) < 10){

$d['geo'] = str_replace('➕', '', $d['geo']);
$j = str_replace('{kash}', $d['geo'], til(uspeshno));

rg('sendmessage', $cid, $j);
$db->exec("UPDATE users SET beeline='".$tex."', geo='#' WHERE user_id='".$cid."' ");
}}}
if($d['geo'] == "➕HUMO") {
if (preg_match('/1|2|3|4|5|6|7|8|9|0/i', $tex)){
$tex = str_replace(' ', '', $tex);
if (strlen($tex) > 15){
$no = substr($tex, 0, 16);
$d['geo'] = str_replace('➕', '', $d['geo']);
$j = str_replace('{kash}', $d['geo'], til(uspeshno));

rg('sendmessage', $cid, $j);
$db->exec("UPDATE users SET humo='".$no."', geo='#' WHERE user_id='".$cid."' ");
}}}
if($tex == til(menu)) {
rg('sendmessage', $cid, til(menu), $menu);
}
if($dat == "clear") {
$db->exec("UPDATE users SET geo='#', qiwi='', yandex='', uzcard='', wmr='', beeline='', xbetrub='', xbetusd='', xbetuzs='', wmz='', sberbank='', humo='', payeer='' WHERE user_id='".$chid."' ");

rg('deleteMessage', $chid, true, true, $mid);
rg('sendmessage', $chid, til(toza));

}


$wmzzz = $db->queryRow('SELECT * FROM valyut WHERE turi = "wmz" ');
$wmzz = $wmzzz['sotish'];
if($tex == til(kurs)) {
$rez = json_encode(['inline_keyboard'=>[[['text'=>til(rezerv), 'callback_data'=>"rezerv"]]]]);
$mm = til(prodaj)."\n1 QIWI RUB = `".$qiv."` UZS\n1 PAYEER RUB = `".$payerrub."` UZS\n1 PAYEER USD = `".$payerusd."` UZS\n1 YANDEX RUB = `".$yan."` UZS\n1 WMR = `".$wme."` UZS\n1 WMZ = `".$wmzz."` UZS\n1 Сбербанк RUB = `".$sb."` UZS\n1 Beeline GB = `".$beeline."` UZS\n1 1XBET RUB = `".$xbetrub."` UZS\n1 1XBET USD = `".$xbetusd."` UZS\n1 1XBET UZS = `".$foiz."%`\n\n".til(pokup)."\n1 QIWI RUB = `".$qi."` UZS\n1 PAYEER RUB = `".$payerrubo."` UZS\n1 PAYEER USD = `".$payerusdo."` UZS\n1 YANDEX RUB = `".$ya."` UZS\n1 WMR = `".$wm."` UZS\n1 WMZ = `".$wmzo."` UZS\n1 Сбербанк RUB = `".$sbo."` UZS";
rg('sendmessage', $cid, $mm, $rez);

$db->exec("UPDATE users SET geo='#' WHERE user_id='".$cid."' ");
//$db->exec("UPDATE obmen SET otype='', btype='', time='' WHERE cid='".$cid."' AND sts = 'loading' ");
}
 if ($dat == "rezerv") {
$oo = til(rezirv)."\nUZCARD = `".get('byudjet/uzcard.rg')."` UZS\nHUMO UZS = `".get('byudjet/humo.rg')."` UZS\nQIWI RUB = `".get('byudjet/qiwi.rg')."` RUB\nPAYEER RUB = `".get('byudjet/payerrub.rg')."` RUB\nPAYEER USD = `".get('byudjet/payerusd.rg')."` USD\nYandex RUB = `".get('byudjet/yandex.rg')."` RUB\nWMR = `".get('byudjet/wmr.rg')."` RUB\nWMZ = `".get('byudjet/wmz.rg')."` USD\nСбербанк RUB = `".get('byudjet/sberbank.rg')."` RUB\nBeeline MB = `".get('byudjet/beeline.rg')."` MB\n1XBET RUB = `".get('byudjet/xbetrub.rg')."` RUB\n1XBET USD = `".get('byudjet/xbetusd.rg')."` USD\n1XBET UZS = `".get('byudjet/xbetuzs.rg')."` UZS";

rg('editMessageText', $chid, $oo, json_encode(['inline_keyboard'=>[[['text'=>til(kkurs), 'callback_data'=>"kursval"]]]]), $update->callback_query->message->message_id);
}
if ($dat == "kursval") {
$rez = json_encode(['inline_keyboard'=>[[['text'=>til(rezerv), 'callback_data'=>"rezerv"]]]]);
$mm = til(prodaj)."\n1 QIWI RUB = `".$qiv."` UZS\n1 PAYEER RUB = `".$payerrub."` UZS\n1 PAYEER USD = `".$payerusd."` UZS\n1 YANDEX RUB = `".$yan."` UZS\n1 WMR = `".$wme."` UZS\n1 WMZ = `".$wmzz."` UZS\n1 Сбербанк RUB = `".$sb."` UZS\n1 Beeline GB = `".$beeline."` UZS\n1 1XBET RUB = `".$xbetrub."` UZS\n1 1XBET USD = `".$xbetusd."` UZS\n1 1XBET UZS = `".$foiz."%`\n\n".til(pokup)."\n1 QIWI RUB = `".$qi."` UZS\n1 PAYEER RUB = `".$payerrubo."` UZS\n1 PAYEER USD = `".$payerusdo."` UZS\n1 YANDEX RUB = `".$ya."` UZS\n1 WMR = `".$wm."` UZS\n1 WMZ = `".$wmzo."` UZS\n1 Сбербанк RUB = `".$sbo."` UZS";
rg('editMessageText', $chid, $mm, $rez, $mid);
}
include 'refe.php';//REFERAL##########################################


if($tex == til(istoriya)) {
$mez = json_encode(['one_time_keyboard'=>true, 'resize_keyboard'=>true,
'keyboard'=>[[['text'=>til(my)],['text'=>til(obshiy)]],[['text'=>til(menu)]]]]);
rg('sendmessage', $cid, til(razdel), $mez);
$db->exec("UPDATE users SET geo='#' WHERE user_id='".$cid."' ");
//$db->exec("UPDATE obmen SET otype='', btype='' WHERE cid='".$cid."' AND sts = 'loading' ");
 }
if($tex == til(my)) {
$co = $db->queryValue('SELECT COUNT (*) FROM obmen WHERE cid = "'.$cid.'" AND (sts = "success" OR sts = "tekshiruv" OR sts = "otmen") ');
$my = $db->queryRows('SELECT * FROM obmen WHERE cid = "'.$cid.'" AND (sts = "success" OR sts = "tekshiruv" OR sts = "otmen") ORDER BY time DESC LIMIT 20');
$i = 0;
foreach($my as $dy) {
$sts = str_replace('tekshiruv', til(prover), $dy['sts']);
$sts = str_replace('success', til(tulandi), $sts);
$sts = str_replace('otmen', til(tulanmadi), $sts);

$mi = "*ID: ".$dy['id']."\n".til(berish)." ".$dy['berish']." ".$dy['btype']."\n".til(olish)." ".$dy['olish']." ".$dy['otype']."\n".til(time)." ".date('d.m.y / H:i:s', $dy['time'])."\n".til(sts)." ".$sts."*";
rg('sendmessage', $cid, $mi);
$i++;
} $hi = til(posledniy); $hi = str_replace('{co}', $i, $hi);
rg('sendmessage', $cid, "*".$hi."*");
}
if ($tex == til(obshiy)) {
$i = json_encode(['inline_keyboard'=>[[['text'=>til(ulan), 'url'=>"t.me/myobmenchek"]]]]);
$ne = til(vseoperat);
rg('sendmessage', $cid, $ne, $i);
}

if ($tex == til(aloqa)) {
$i = json_encode(['inline_keyboard'=>[[['text'=>til(typing), 'url'=>"t.me/myobmeuz"]]]]);
$ne = til(svyaz);
$ne = str_replace('{nomer}', $aloqa, $ne);
rg('sendmessage', $cid, $ne, $i);
$db->exec("UPDATE users SET geo='#' WHERE user_id='".$cid."' ");
//$db->exec("UPDATE obmen SET otype='', btype='' WHERE cid='".$cid."' AND sts = 'loading' ");
}
if($tex == til(biz)) {
rg('sendmessage', $cid, "*".$company."* ".til(comp)." ".$site."\n\n".til(dasturchi));
$db->exec("UPDATE users SET geo='#' WHERE user_id='".$cid."' ");
//$db->exec("UPDATE obmen SET otype='', btype='' WHERE cid='".$cid."' AND sts = 'loading' ");
}

} else {

if ($em['geo'] == "start") {

$remove = json_encode(array('remove_keyboard' => true));
rg('sendmessage', $cid, til(fio), $remove);
sleep(2);
$db->exec("UPDATE users SET geo='fio' WHERE user_id='".$cid."' ");
}
}

if ($em['geo'] == "fio") {
$ku = explode(' ', $tex);
if (strlen($ku[1]) > 3) {
$nomr = json_encode(['resize_keyboard'=>true, 'keyboard' => [[["text"=>"⏳ ".til(vzitka),'request_contact' =>true],],]]);
rg('sendmessage', $cid, til(vizet), $nomr);
 $db->exec("UPDATE users SET fio='".$ku[0]." ".$ku[1]." ".$ku[2]."', geo='raqam' WHERE user_id='".$cid."' ");
} else {
rg('sendmessage', $cid, til(ismi));
}}

if ($em['geo'] == "raqam") {
if ($message->contact) {
//$nu = explode('+99', $message->contact->phone_number);

rg('sendmessage', $cid, til(spasiba), $menu);
$db->exec("UPDATE users SET nomer='".$message->contact->phone_number."', geo='#' WHERE user_id='".$cid."' ");
}
}

if(in_array($cid, $admin)) {
if(mb_stripos($tex,"##") !== false) {
$mid = $message->reply_to_message->message_id;

file_put_contents('rass.txt', json_encode($update));

bot('sendmessage', ['chat_id'=>$cid, 'text'=>"*Tayyor:* /Yubor Yuborishga tayyor", 'parse_mode'=>"markdown"]);
// строка, которую будем записывать
$texti = file_get_contents('txt.txt');
 
$fp = fopen("cron.php", "w");
 
fwrite($fp, $texti);
 
fclose($fp);
}
if ($tex == "/Yubor") {
file_put_contents('next.txt', '0');
file_put_contents('stop.txt', '0');
bot('sendmessage', ['chat_id'=>"652903849", 'text'=>"Habar yetkazilmoqda..."]);
file_get_contents('http://myobmenuz.cf/cron.php');
}

if(mb_stripos($tex,"/qiwi") !== false || mb_stripos($tex,"/uzcard") !== false || mb_stripos($tex,"/wmr") !== false || mb_stripos($tex,"/yandex") !== false || mb_stripos($tex,"/wmz") !== false || mb_stripos($tex,"/qiwiru") !== false ||  mb_stripos($tex,"/beeline") !== false || mb_stripos($tex,"/sberbank") !== false || mb_stripos($tex,"/xbetrub") !== false || mb_stripos($tex,"/xbetusd") !== false || mb_stripos($tex,"/humo") !== false || mb_stripos($tex,"/xbetuzs") !== false || mb_stripos($tex,"/payerrub") !== false || mb_stripos($tex,"/payerusd") !== false) {

$zax = explode('=', $tex);
preg_match_all('|/(.*)=|Uis', $tex, $morg);
file_put_contents('byudjet/'.$morg[1][0].'.rg', $zax[1]);
rg('sendmessage', $cid, "*✅ ".$morg[1][0]."da zahira mablag' ".$zax[1]."*");
} 


if(mb_stripos($tex,"/stop") !== false) {
$st = explode('=', $tex);
file_put_contents('off.morgan', $st[1]);
rg('sendmessage', $cid, "*✅ ".$st[1]." -da ochishni unutmang*");
}
if(mb_stripos($tex,"/foiz") !== false) {
$st = explode('=', $tex);
file_put_contents('byudjet/foiz.txt', $st[1]);
rg('sendmessage', $cid, "*✅ ".$st[1]." % qilindi*");
}

if($tex == "/admin") {
$admi = "*Kerakli buyruqlar yodda saqlang:*\n\n◽ Sotish va Olish kursini taxrirlash (namuna:)\n\n`#sotish#qiwi#145 / #olish#qiwi#125`\n\n`#sotish#wmr#145 / #olish#wmr#125`\n\n`#sotish#wmz#9000 / #olish#wmz#8400`\n\n`#sotish#yandex#145 / #olish#yandex#125`\n\n`#sotish#payerrub#140 / #olish#payerrub#160`\n\n`#sotish#payerusd#8000 / #olish#payerusd#10000`\n\n`#sotish#sberbank#145 / #olish#sberbank#125`\n\n`#sotish#xbetrub#145 / #olish#xbetrub#125`\n\n`#sotish#xbetusd#9000 / #olish#xbetusd#8400`\n\n`#sotish#beeline#9000`\n\n◽ Zaxira pullarni taxrirlash (namuna:)\n\n`/qiwi=17000\n/uzcard=18000\n/yandex=19000\n/wmr=20000\n/wmz=50\n/payerrub=110\n/payerusd=100\n/sberbank=1001\n/beeline=10000\n/xbetrub=1111\n/xbetusd=555\n/paynet=12345\n/xbetuzs=5377732`\n\n🌍Qo'shimcha funksiyalar:\n/stop=Vaqtincha ish faolyat to'xtatish\n`##` Hammaga yuboriladigan xabarni tayyorlash (рассылка) va /Yubor ni bosib yuborish mumkin";
rg('sendmessage', $cid, $admi);
}

if (mb_stripos($tex, "/tekshir") !==false) {
	$idg = explode('=', $tex)[1];
	$prover = $db->queryRows('SELECT * FROM users WHERE ref = "'.$idg.'" ');
$p = '';
for($i=0; $i<count($prover); $i++) {

	$o_b = $db->queryRows('SELECT * FROM obmen WHERE cid = "'.$prover[$i]['user_id'].'" AND sts = "success" ');
if (count($o_b[0]['sts']) > 0) {
$ob = '';
for($l=0; $l<count($o_b); $l++) {

	$ob .= "` __________________________________`
├ B/O: ".$o_b[$l]['btype']." / ".$o_b[$l]['otype']."
├  ⬆️  ".$o_b[$l]['berish']." ⬇️  ".$o_b[$l]['olish']."
├ ⏰ Sana: ".date('H:i / Y.m.d', $o_b[$l]['time'])."\n";

}

} else {
$ob = "Hali almashuv qilmagan";
}
$p .= "👤* ".$i.")* [".$prover[$i]['user_id']."](tg://user?id=".$prover[$i]['user_id'].") Hisob: ".$prover[$i]['hisob']."
".$ob."\n\n";
}
	rg('sendmessage', $cid, $p);
	}

if (mb_stripos($tex, "/belgi") !== false) {
$belgi = explode('=', $tex);
$beli = explode('-', $tex);

if (!empty($belgi[1])) {
if($db->queryValue('SELECT COUNT (*) FROM belgi WHERE xid = "'.$belgi[1].'" ') == 0) {rg('sendmessage', $cid, "*Qo'shildi! endi bu hisob raqam egasiga komissiyasiz to'lov qilishingiz kerak*"); $db->exec('INSERT INTO "belgi" ("xid")
    VALUES ("'.$belgi[1].'")'); } } else{ rg('sendmessage', $cid, "*Belgilar daftaridan o'chirildi*");
$db->exec("DELETE FROM belgi WHERE xid='".$beli[1]."'");
}
}

}//adminstva

if (mb_stripos($tex,"/start ") !== false) {
$od = explode('/start ', $tex);
if($od[1] == $cid) {  if($db->queryValue('SELECT COUNT (*) FROM users WHERE user_id = "'.$cid.'" ') == 0) { $db->exec('INSERT INTO "users" ("user_id")
    VALUES ("'.$cid.'")'); } } else { $refc = $db->queryValue('SELECT COUNT (*) FROM users WHERE user_id = "'.$cid.'" AND ref = "'.$od[1].'" '); 
if($refc == 0) {
if($db->queryValue('SELECT COUNT (*) FROM users WHERE user_id = "'.$cid.'" ') == 0) {
$db->exec('INSERT INTO "users" ("user_id", "ref")
    VALUES ("'.$cid.'", "'.$od[1].'")'); 
 rg('sendmessage', $od[1], "*У вас есть новый реферал / Sizda yangi referal:* [".$message->from->first_name."](tg://user?id=".$cid.") !"); }
}
}
$refe = $db->queryValue('SELECT COUNT (user_id) FROM users WHERE ref = "'.$cid.'" ');//reflarim soni

rg('sendmessage', $cid, "Выберите язык интерфейса💬\n\nInterfeys tilini tanlang", json_encode(['inline_keyboard'=>[[['text'=>"Русский", 'callback_data'=>"ru"],['text'=>"O'zbek tili", 'callback_data'=>"uz"]]]]));
 
}
?>