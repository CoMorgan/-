<?php

/**
 * Colin Morgan
 * 22.09.2021
 * #Korona Virus
 * Telegram: @C_MoRGaN
 **/
require 'class.php';
require 'sqlite.php';
$db = new Db('buyurtma.db');
use app\TelegramBot;

date_default_timezone_set('Asia/Tashkent');

$bot = new TelegramBot;

$data = $bot->getData("php://input");

if ($data['message']) {
    $chat_id = $data['message']['chat']['id'];
    $userid = $data['message']['from']['id'];
    $username = $data['message']['from']['username'];
    $ism = $data['message']['from']['first_name'] . ' ' . $data['message']['from']['last_name'];
    $text = $data['message']['text'];
    $message_id = $data['message']['message_id'];
}

if ($data['callback_query']) {
//CALLBACK
    $callback = $data['callback_query'];
    $callid = $callback['id'];
    $i_m_id = $callback['inline_message_id'];
    $cdata = $callback['data'];
    $chat_id = $callback['message']['chat']['id'];
    $message_id = $callback['message']['message_id'];
    $text = $callback['message']['text'];
}
$admin = '266873587';//tasdiqlovchi admin
$adm = ['266873587', '389378714', '1115067337'];//

$buyurtma = $bot->InlineKeyboard([[['text' => "Buyurtma qilish", 'callback_data' => "buyurtma"]]]);
$remove = json_encode(array('remove_keyboard' => true));

if ($text == "/start") {
	
$bot->rg('sendmessage', $chat_id, "Buyurtma qilish botiga hush kelibsiz!", $buyurtma);
$count = $db->queryValue('SELECT COUNT (*) FROM buyurtma WHERE cid = "'.$chat_id.'" ');
if ($count == 0) {
$db->exec('INSERT INTO "buyurtma" ("cid")
    VALUES ("'.$chat_id.'")');
}
}

if ($cdata == "buyurtma") {
	$number = json_encode(['resize_keyboard'=>true, 'keyboard' => [[["text"=>"📲 Raqam yuborish",'request_contact' =>true],],]]);

	$bot->rg('sendmessage', $chat_id, "Telefon raqamingizni quyidagi tugmaga bosib yuboring", $number);
$bot->dMessage($chat_id, $message_id);
	}
	
	if ($data['message']['contact'] == true) {
		
		$bot->rg('sendmessage', $chat_id, "Ism Familiyangizni yozing\nMasalan: `Ivanov Ivan`", json_encode(
['force_reply'=>true,'selective'=>false]));
$raqam = str_replace("+", "", $data['message']['contact']['phone_number']);
$db->update('buyurtma', array('raqam' => $raqam), 'cid=:id', array(':id' => $chat_id)); 

				}
				if (mb_stripos($data['message']['reply_to_message']['text'], "Ism") !==false) {
					$bot->rg('sendmessage', $chat_id, "Yashash manzilingizni yozing", json_encode(
['force_reply'=>true,'selective'=>false]));
					$db->update('buyurtma', array('fio' => $text), 'cid=:id', array(':id' => $chat_id)); 

					}
						if (mb_stripos($data['message']['reply_to_message']['text'], "Yashash") !==false) {
					$bot->rg('sendmessage', $chat_id, "Xabaringiz matnini to'liq bayon eting", json_encode(
['force_reply'=>true,'selective'=>false]));
					$db->update('buyurtma', array('adres' => $text), 'cid=:id', array(':id' => $chat_id)); 

					}
					
				if (mb_stripos($data['message']['reply_to_message']['text'], "bayon") !==false) {
					$row = $db->queryRow('SELECT * FROM buyurtma WHERE cid = "'.$chat_id.'" ');
					$matn = "🎩 FIO: {$row['fio']}
📍 Manzil: {$row['adres']}
📱Raqam: {$row['raqam']}

📧 Xabar: `{$text}`";
$tasdiq = $bot->InlineKeyboard([[['text' => "Yuborish", 'callback_data' => "success"]],[['text' => "Bekor qilish", 'callback_data' => "not"]]]);
$bot->rg('sendmessage', $chat_id, $matn, $tasdiq);
}


		if ($cdata == "success")	{
				$row = $db->queryRow('SELECT * FROM buyurtma WHERE cid = "'.$chat_id.'" ');
					$matn = "🎩 FIO: {$row['fio']}
📍 Manzil: {$row['adres']}
📱Raqam: {$row['raqam']}
📨 Telegram: [#Account](tg://user?id=$chat_id)

📧 Xabar: `".explode("Xabar:", $text)[1]."`";

$bot->rg('sendmessage', $admin, $matn);
$bot->rg('sendmessage', $chat_id, "Buyurtmangiz uchun rahmat tez orada siz bilan bog'lanishadi.");
$bot->rg('sendmessage', $chat_id, "Asosiy menyu", $buyurtma);
	
				}
				if ($cdata == "not") {
					$bot->rg('sendmessage', $chat_id, "Buyurtma qilish uchun tugmaga bosing",$buyurtma);
					$bot->dMessage($chat_id, $message_id);
					}
					
					/*
					22.09.2020 / 11:31
					*/
?>


